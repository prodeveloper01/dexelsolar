
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="Dexel Solar is a green energy investment platform where you can rent solar panels & turbines energy to make money!">
    <meta name="author" content="Dexel Solar">
    <link rel="icon" href="/energy/images/favicon.ico">

   <title>{{ $general->sitename($page_title) }}</title>
    
    
      <link rel="shortcut icon" type="image/png" href="{{ asset(imagePath()['logoIcon']['path'] .'/favicon.png') }}"/>
        <!-- bootstrap 4  -->
      <link rel="stylesheet" href="{{ asset($activeTemplateTrue.'/css/vendor/bootstrap.min.css') }}">
      <!-- fontawesome 5  -->
      <link rel="stylesheet" href="{{ asset($activeTemplateTrue.'/css/all.min.css') }}">
      <!-- line-awesome webfont -->
      <link rel="stylesheet" href="{{ asset($activeTemplateTrue.'/css/line-awesome.min.css') }}">
      <!-- image and videos view on page plugin -->
      <link rel="stylesheet" href="{{ asset($activeTemplateTrue.'/css/lightcase.css') }}">
      
      <link rel="stylesheet" href="{{ asset($activeTemplateTrue.'/css/vendor/animate.min.css') }}">
      <!-- custom select css -->
      <link rel="stylesheet" href="{{ asset($activeTemplateTrue.'/css/vendor/nice-select.css') }}">
      <!-- slick slider css -->
      <link rel="stylesheet" href="{{ asset($activeTemplateTrue.'/css/vendor/slick.css') }}">
      <!-- dashdoard main css -->
      <link rel="stylesheet" href="{{ asset($activeTemplateTrue.'/css/main.css') }}">
      <link rel="stylesheet" href="{{ asset($activeTemplateTrue.'/css/custom.css') }}">
        <link rel="stylesheet" href="{{ asset(asset($activeTemplateTrue)."/css/color.php?color1=$general->base_color&color2=$general->secondary_color") }}">
 
    
	<!-- Vendors Style-->
	<link rel="stylesheet" href="https://wtpower.io/assets/css/vendors_css.css">
        
	<!-- Revolution Slider -->		
	<link rel="stylesheet" type="text/css" href="https://wtpower.io/assets/revolution-slider/revolution/fonts/pe-icon-7-stroke/css/pe-icon-7-stroke.css">
	<link rel="stylesheet" type="text/css" href="https://wtpower.io/assets/revolution-slider/revolution/css/settings.css">
	<link rel="stylesheet" type="text/css" href="https://wtpower.io/assets/revolution-slider/revolution/css/layers.css">
	<link rel="stylesheet" type="text/css" href="https://wtpower.io/assets/revolution-slider/revolution/css/navigation.css">  
	  
	<!-- Style-->  
	<link rel="stylesheet" href="https://wtpower.io/assets/css/style.css">
	<link rel="stylesheet" href="https://wtpower.io/assets/css/skin_color.css">
     
  </head>

<style>


nav.nav-white.nav-transparent .menu li a {
    color: #000 !important;
}
.topbar-social ul li a {
    color: #000 !important;
}
</style>

<body class="theme-primary">
	
	<!-- The social media icon bar -->

	<header class="top-bar">
		<div class="topbar">
		  <div class="container">
			<div class="row justify-content-end">
			  <div class="col-md-4 col-12 d-md-block d-none">
				<div class="topbar-social text-center text-md-start topbar-left">
				  <ul class="list-inline d-md-flex d-inline-block">
					<li class="ms-10 pe-10"><a href="#"><i class="text-white fa fa-question-circle"></i> Ask a Question</a></li>
				  </ul>
				</div>
			  </div>
			  <div class="col-lg-8 col-md-8 col-12">
				<div class="topbar-social text-center text-md-right">
				  <ul class="list-inline d-md-flex justify-content-end">
					<li class="ms-10 pe-10"><a href="#"><i class="text-white fa fa-envelope"></i> info@dexelsolar.com</a></li>
					<li class="ms-10 pe-10"><a href="#"><i class="text-white fa fa-phone"></i>+996 999 153 198</a></li>
				  </ul>
				</div>
			  </div>
			 </div>
		  </div>
		</div>

		<nav hidden class="nav-white nav-transparent">
			<div class="nav-header">
				<a href="/" class="brand">
					<img src="{{ asset('assets/images/logoIcon/logo.png') }}" class="img-fluid" alt="Dexel Solar Logo"/>
				</a>
				<button class="toggle-bar">
					<span class="ti-menu"></span>
				</button>	
			</div>								
			<ul class="menu">
				<li><a href="#">Home</a></li>
				<li><a href="#">Download App</a></li>
				<li><a href="#">Plans</a></li>
				<li><a href="#">Whatsapp Group</a></li>				
				<li><a href="/login">Login</a></li>	
				<li><a href="/register">Register</a></li>
			</ul>


		</nav>
	</header>
	
	<!--Slider Here-->
	<div id="home" class="section dart-no-padding-tb">
		<div id="revo_main_wrapper" class="rev_slider_wrapper fullwidthbanner-container">
			<div id="rev_slider_251_115" class="rev_slider fullwidthabanner" style="display:none;" data-version="5.4.1">
				<ul>
					<!-- SLIDE 1 -->
					<li data-index="rs-01" data-transition="fade" data-slotamount="default" data-easein="Power3.easeInOut" data-easeout="Power3.easeInOut" data-masterspeed="2000" data-fsmasterspeed="1500" class="rev_gradient">

						<!-- MAIN IMAGE -->
						<img src="https://wtpower.io/assets/images/slider_bg.jpg" alt="" data-bgposition="center center" data-bgfit="cover" data-bgrepeat="no-repeat" class="rev-slidebg" data-bgparallax="10"  data-no-retina>
						<!-- LAYER NR. 1 -->
						<div class="tp-caption tp-resizeme text-white"
							 data-x="['center','center','center','center']" data-hoffset="['0','0','0','0']"
							 data-y="['middle','middle','middle','middle']" data-voffset="['0','0','0','0']"
							 data-fontsize="['55','55','40','40']"
							 data-lineheight="['55','55','40','40']"
							 data-whitespace="nowrap" data-responsive_offset="on"
							 data-width="['none','none','none','none']" data-type="text"
							 data-textalign="['center','center','center','center']"
							 data-transform_idle="o:1;" data-transform_in="z:0;rX:0;rY:0;rZ:0;sX:0.9;sY:0.9;skX:0;skY:0;opacity:0;s:1500;e:Power3.easeInOut;" data-transform_out="y:[100%];s:1000;e:Power2.easeInOut;s:1000;e:Power2.easeInOut;" data-mask_out="x:inherit;y:inherit;s:inherit;e:inherit;"
							 data-start="1200" data-splitin="none" data-splitout="none">
							Welcome to Dexel Solar
						</div>
						<div class="tp-caption tp-resizeme whitecolor"
							 data-x="['center','center','center','center']" data-hoffset="['0','0','0','0']"
							 data-y="['middle','middle','middle','middle']" data-voffset="['50','50','50','50']"
							 data-whitespace="nowrap" data-responsive_offset="on"
							 data-width="['none','none','none','none']" data-type="text"
							 data-textalign="['center','center','center','center']" data-fontsize="['24','24','20','20']"
							 data-transform_idle="o:1;"
							 data-transform_in="z:0;rX:0deg;rY:0;rZ:0;sX:2;sY:2;skX:0;skY:0;opacity:0;s:1000;e:Power2.easeOut;"
							 data-transform_out="s:1000;e:Power3.easeInOut;s:1000;e:Power3.easeInOut;"
							 data-mask_in="x:0px;y:0px;s:inherit;e:inherit;"
							 data-start="1500" data-splitin="none" data-splitout="none">
							<p style="line-height: 23px; font-weight: 400; font-size: 18px; color: #ffffff;">Earn highest profits with small investments with Dexel Solar a green energy investment platform!</p>
						</div>

						<div class="tp-caption tp-resizeme"
							 data-x="['center','center','center','center']" data-hoffset="['0','0','0','0']"
							 data-y="['middle','middle','middle','middle']" data-voffset="['120','120','120','120']"
							 data-width="200" data-height="none"
							 data-whitespace="normal" data-type="button"
							 data-actions='' data-responsive_offset="on"
							 data-textAlign="['center','center','center','center']"
							 data-margintop="[0,0,0,0]" data-marginright="[0,0,0,0]"
							 data-marginbottom="[0,0,0,0]" data-marginleft="[0,0,0,0]"
							 data-frames='[{"delay":700,"speed":2000,"frame":"0","from":"sX:1;sY:1;opacity:0;fb:40px;","to":"o:1;fb:0;","ease":"Power4.easeInOut"},{"delay":"wait","speed":300,"frame":"999","to":"opacity:0;fb:0;","ease":"Power3.easeInOut"},{"frame":"hover","speed":"200","ease":"Linear.easeNone","to":"o:1;rX:0;rY:0;rZ:0;z:0;fb:0;"}]'
							 style=" box-shadow:none;box-sizing:border-box;-moz-box-sizing:border-box;-webkit-box-sizing:border-box;">
							<a href="/login" class="btn btn-primary">login</a>
							<a href="/register" class="btn btn-primary">Register</a>
						</div>
					</li>

					<!-- SLIDE 2  -->
					<li data-index="rs-02" data-transition="fade" data-slotamount="default" data-easein="Power3.easeInOut" data-easeout="Power3.easeInOut" data-masterspeed="2000" data-fsmasterspeed="1500">

						<!-- MAIN IMAGE -->
						<img src="https://wtpower.io/assets/images/slider_bg_2.jpg" alt="" data-bgposition="center center" data-bgfit="cover" data-bgrepeat="no-repeat" class="rev-slidebg" data-bgparallax="10" data-no-retina>
						<!-- LAYER NR. 1 -->
						<div class="tp-caption tp-resizeme text-white"
							 data-x="['center','center','center','center']" data-hoffset="['0','0','0','0']"
							 data-y="['middle','middle','middle','middle']" data-voffset="['0','0','0','0']"
							 data-fontsize="['55','55','40','40']"
							 data-lineheight="['55','55','40','40']"
							 data-whitespace="nowrap" data-responsive_offset="on"
							 data-width="['none','none','none','none']" data-type="text"
							 data-textalign="['center','center','center','center']"
							 data-transform_idle="o:1;"
							 data-transform_in="x:-50px;opacity:0;s:2000;e:Power3.easeOut;"
							 data-transform_out="s:1000;e:Power3.easeInOut;s:1000;e:Power3.easeInOut;"
							 data-start="1000" data-splitin="none" data-splitout="none">
							 Earn More with us.
						</div>
						<div class="tp-caption tp-resizeme whitecolor"
							 data-x="['center','center','center','center']" data-hoffset="['0','0','0','0']"
							 data-y="['middle','middle','middle','middle']" data-voffset="['50','50','50','50']"
							 data-whitespace="nowrap" data-responsive_offset="on"
							 data-width="['none','none','none','none']" data-type="text"
							 data-textalign="['center','center','center','center']" data-fontsize="['24','24','20','20']"
							 data-transform_idle="o:1;"
							 data-transform_in="z:0;rX:0deg;rY:0;rZ:0;sX:2;sY:2;skX:0;skY:0;opacity:0;s:1000;e:Power2.easeOut;"
							 data-transform_out="s:1000;e:Power3.easeInOut;s:1000;e:Power3.easeInOut;"
							 data-mask_in="x:0px;y:0px;s:inherit;e:inherit;"
							 data-start="1500" data-splitin="none" data-splitout="none">
							<p style="line-height: 23px; font-weight: 400; font-size: 18px; color: #ffffff;">Rent green energy solar panels and turbines to make highest profits with Dexel Solar!</p>
						</div>
						<div class="tp-caption tp-resizeme"
							 data-x="['center','center','center','center']" data-hoffset="['0','0','0','0']"
							 data-y="['middle','middle','middle','middle']" data-voffset="['120','120','120','120']"
							 data-width="200" data-height="none"
							 data-whitespace="normal" data-type="button"
							 data-actions='' data-responsive_offset="on"
							 data-textAlign="['center','center','center','center']"
							 data-margintop="[0,0,0,0]" data-marginright="[0,0,0,0]"
							 data-marginbottom="[0,0,0,0]" data-marginleft="[0,0,0,0]"
							 data-frames='[{"delay":700,"speed":2000,"frame":"0","from":"sX:1;sY:1;opacity:0;fb:40px;","to":"o:1;fb:0;","ease":"Power4.easeInOut"},{"delay":"wait","speed":300,"frame":"999","to":"opacity:0;fb:0;","ease":"Power3.easeInOut"},{"frame":"hover","speed":"200","ease":"Linear.easeNone","to":"o:1;rX:0;rY:0;rZ:0;z:0;fb:0;"}]'
							 style=" box-shadow:none;box-sizing:border-box;-moz-box-sizing:border-box;-webkit-box-sizing:border-box;">
							<a href="/user/login" class="btn btn-primary">login</a>
							<a href="/register" class="btn btn-primary">Register</a>
						</div>
					</li>
				</ul>
			</div>
		</div>
	</div>
    
	<section class="py-100 bg-white">
		<div class="container">
			<div class="row">
				<div class="col-lg-6 col-12" data-aos="fade-up">
					<div class="section-heading mb-30">
						<h1 class="heading fw-500">Dexel<span class="text-primary">Solar </span>, Green energy investment platform to earn daily highest earnings.</h1>
						<hr class="p-1 bg-primary w-100 ms-0">
					</div>
					<p class="fs-16 mb-4">Dexel Solar is making money by installing solar panels and turbines that we purchase using our investors investments and then we start making energy and we sell that energy back to goverment.</p>
					<p class="fs-16 mb-4">Fuel is distroying our planet's environment to protect it we need to harvest power from sun using solar panels and generate green energy with turbines.</p>
					<a href="/register" class="btn btn-primary">Join Now</a>
				</div>
				<div class="col-lg-6 col-12" data-aos="fade-up">
					<img src="/images/s1.png" class="img-fluid" alt="" />
				</div>
			</div>
		</div>
	</section>
	
	<section class="py-100">
      <div class="container">
        <div class="row justify-content-center">
          <div class="col-md-6 col-12 text-center" data-aos="fade-up">			  
			<div class="section-heading mb-30">
				<h2 class="heading fw-500">Services <br> <span class="text-primary"> We Provide</span></h2>
				<hr class="p-1 bg-primary w-100">
				<p class="fs-16">Through our experienced operations team we can handle various kind of supply chain operations and services</p>
			</div>
          </div>
        </div>
      </div>
      <div class="container">
        <div class="row">
            
        <div class="col-lg-3 col-md-6 text-center" data-aos="fade-up">
            <div class="service-box mt-5">
              <br/>    
              <img src="https://wtpower.io/assets/images/spec_1.png" alt="">
              <br/><br/>
              <h4 class="mb-20 px-30">Solar System</h4>
			  <a href="/register" class="btn btn-primary-light mb-30">Buy Energy</a>
            </div>
          </div>
          
        <div class="col-lg-3 col-md-6 text-center" data-aos="fade-up">
            <div class="service-box mt-5">
              <br/>    
              <img src="https://wtpower.io/assets/images/spec_2.png" alt="">
              <br/><br/>
              <h4 class="mb-20 px-30">Solar Pv System</h4>
			  <a href="/register" class="btn btn-primary-light mb-30">Buy Energy</a>
            </div>
          </div>
          
        <div class="col-lg-3 col-md-6 text-center" data-aos="fade-up">
            <div class="service-box mt-5">
              <br/>    
              <img src="https://wtpower.io/assets/images/spec_3.png" alt="">
              <br/><br/>
              <h4 class="mb-20 px-30">Wind Generators</h4>
			  <a href="/register" class="btn btn-primary-light mb-30">Buy Energy</a>
            </div>
          </div>
          
        <div class="col-lg-3 col-md-6 text-center" data-aos="fade-up">
            <div class="service-box mt-5">
              <br/>    
              <img src="https://wtpower.io/assets/images/spec_4.png" alt="">
              <br/><br/>
              <h4 class="mb-20 px-30">Alternative Energy</h4>
			  <a href="/register" class="btn btn-primary-light mb-30">Buy Energy</a>
            </div>
          </div>
          
          

		            
        </div>
      </div>
    </section>
<hr>
	
<!--- Plans --->
<section class="py-50">
		<div class="container">
			<div class="row justify-content-center">
				<div class="col-lg-7 col-12 text-center">
					<h1 class="text-uppercase mb-15">Dexel Solar<br> <span class="fw-400 fs-24"> Choose the best</span></h1>
					<p>You can start with minimum 100 every plan is a great plan but bigger plans have bigger earnings. </p>
				</div>
			</div>
			
			<div class="row mt-30">
              <div class="row gap-y text-center">
    <section class="cmn-section price">
    	<div class="container">
    		<div class="row justify-content-center">
    			@foreach(App\Plan::all() as $plan)
    			<div class="col-xl-4 col-lg-4 col-md-6 mb-4">
    				<div class="single-price">
    					<div class="part-top">
    						<h3>{{ __($plan->name) }}</h3>
    						<h4>{{ __($plan->price + 0) }} {{$general->cur_text}}<br></h4>
    					</div>
    					<div class="part-bottom">
                            <ul>
                                <li>@lang('Plan Details')</li>
                                <li>@lang('Daily Earning') : {{ $plan->daily_limit }} </li>
                                <li>@lang('Referral Bonus') : @lang('Upto') {{ $plan->ref_level }} @lang('Level')</li>
                                <li>@lang('Plan Price') : {{ getAmount($plan->price) }} {{ __($general->cur_text) }}</li>
                                <li>@lang('Validity') : @lang('30 days')</li>
                            </ul>
                            @if(auth()->check())
                            @if(auth()->user()->plan_id == $plan->id)
                            <button class="btn btn-success" disabled>@lang('Current Plan')</button>
                            @else
                            <button class="btn btn-success" data-id="{{ $plan->id }}">@lang('Subscribe Now')</button>
                            @endif
                            @else
                            <button class="btn btn-success" data-id="{{ $plan->id }}">@lang('Subscribe Now')</button>
                            @endif
                        </div>
    				</div>
    			</div>
    			@endforeach
    		</div>
    	</div>
    </section>

    <div id="BuyModal" class="modal fade" role="dialog">
        <div class="modal-dialog">

            <!-- Modal content-->
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title">@lang('Confirmation')</h4>
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                </div>
                <form action="{{route('user.buyPlan')}}" method="POST">
                    <div class="modal-body text-center">

                        {{csrf_field()}}
                        <div class="form-group m-0">
                            <input type="hidden" name="id">
                        </div>
                        <strong>@lang('Are you sure to subscribe this plan ?')</strong>

                    </div>
                    <div class="modal-footer">
                        <button type="submit" class="btn btn-success">@lang('Confirm')</button>
                        <button type="button" class="btn btn-danger" data-dismiss="modal">@lang('Close')</button>
                    </div>

                </form>
            </div>

        </div>
    </div>

			</div>
			</div>
		</div>
	</section>
<!--- Plans --->
	
	<section class="py-100 bg-white">
      <div class="container">
        <div class="row justify-content-center" data-aos="fade-up">
          <div class="col-md-6 col-12 text-center">			  
			<div class="section-heading mb-80">
				<h2 class="heading fw-500">We accept<br> <span class="text-primary">Local Payments</span></h2>
				<hr class="p-1 bg-primary w-100">
				<p class="fs-16">You can deposit & withdraw funds using Jazzcash Easypaisa BankTransfer!</p>
			</div>
          </div>
        </div>
		<div class="row" data-aos="fade-up">
			<div class="col-12">
				<div class="owl-carousel owl-theme" data-nav-dots="false" data-autoheight="true" data-items="6" data-md-items="4" data-sm-items="4" data-xs-items="2" data-xx-items="2" data-space="20">
					<div class="item"><img src="https://wtpower.io/assets/images/jazzcash.png" class="img-fluid" alt="Jazzcash"></div>
					<div class="item"><img src="https://wtpower.io/assets/images/easypaisa.png" class="img-fluid" alt="Easypaisa"></div>
					<div class="item"><img src="https://wtpower.io/assets/images/bank.png" class="img-fluid" alt=""></div>

				</div>
			</div>
		</div>  
        
      </div>
    </section>  
	


	<footer class="footer_three">
		<div class="footer-top bg-dark3 pt-80">
            <div class="container">
                <div class="row">
					<div class="col-lg-3 col-12">
                        <div class="widget">
                            <h4 class="footer-title">About</h4>
							<p class="text-capitalize mb-20">Dexel Solar is a green energy investment platform where you can start making money with just 100PKR investment<br><br>Upto 300% return on your investment & 10 levels referral comissions.</p>
                        </div>
                    </div>
					<div class="col-lg-2 col-12">
						<div class="widget">
							<h4 class="footer-title">Quick Link</h4>
							<ul class="list list-arrow mb-30">
								<li><a href="#">Download App</a></li>
								<li><a href="#">FAQs</a></li>
								<li><a href="mailto:support@dexelsolar.com">Contact</a></li>
								<li><a href="#">Whatsapp</a></li>
								<li><a href="/register">Register</a></li>
								<li><a href="/user/login">Login</a></li>
							</ul>
						</div>
                    </div>											
					<div class="col-lg-4 col-12">
						<div class="widget">
							<h4 class="footer-title">Contact Info</h4>
							<ul class="list list-unstyled mb-30">
								<!--<li> <i class="fa fa-map-marker"></i> FBR Registration Number: 3460343445761</li>-->
								<li> <i class="fa fa-phone"></i> <span class="me-5">+(92) 326-3221-443 </span> | <span class="ms-5">+996 999 153 198</span></li>
								<li> <i class="fa fa-envelope"></i> <span class="me-5">info@dexelsolar.com </span> | <span class="ms-5">support@dexelsolar.com</span></li>
							</ul>
							<div class="social-icons mt-30">
								<ul class="list-unstyled d-flex gap-items-1">
									<li><a href="#" class="waves-effect waves-circle btn btn-social-icon btn-circle btn-facebook"><i class="fa fa-facebook"></i></a></li>
									<li><a href="#" class="waves-effect waves-circle btn btn-social-icon btn-circle btn-twitter"><i class="fa fa-twitter"></i></a></li>
									<li><a href="#" class="waves-effect waves-circle btn btn-social-icon btn-circle btn-linkedin"><i class="fa fa-linkedin"></i></a></li>
									<li><a href="#" class="waves-effect waves-circle btn btn-social-icon btn-circle btn-youtube"><i class="fa fa-youtube"></i></a></li>
								</ul>
							</div>

						</div>
					</div>
					
                </div>				
            </div>
        </div>
		<div class="footer-bottom bg-dark3">
            <div class="container">
                <div class="row align-items-center">
                    <div class="col-md-6 col-12 text-md-start text-center"> © <script>document.write(new Date().getFullYear())</script> <span class="text-white">Dexel Solar</span>  All Rights Reserved.</div>
					<div class="col-lg-6 col-md-6 mt-md-0 mt-20">
						<ul class="payment-icon list-unstyled d-flex gap-items-1 justify-content-md-end justify-content-center">
							<li class="ps-0">
								<a href="javascript:;"><i class="fa fa-cc-amex" aria-hidden="true"></i></a>
							</li>
							<li>
								<a href="javascript:;"><i class="fa fa-cc-visa" aria-hidden="true"></i></a>
							</li>
							<li>
								<a href="javascript:;"><i class="fa fa-credit-card-alt" aria-hidden="true"></i></a>
							</li>
							<li>
								<a href="javascript:;"><i class="fa fa-cc-mastercard" aria-hidden="true"></i></a>
							</li>
							<li>
								<a href="javascript:;"><i class="fa fa-cc-paypal" aria-hidden="true"></i></a>
							</li>
						</ul>
					</div>

                </div>
            </div>
        </div>
	</footer>
	
	
	<!-- Vendor JS -->
	<script src="https://wtpower.io/assets/js/vendors.min.js"></script>	
	<!-- Corenav Master JavaScript -->
    <script src="https://wtpower.io/assets/corenav-master/coreNavigation-1.1.3.js"></script>
    <script src="https://wtpower.io/assets/js/nav.js"></script>
	<script src="https://wtpower.io/assets/vendor_components/OwlCarousel2/dist/owl.carousel.js"></script>
	<script src="https://wtpower.io/assets/vendor_components/bootstrap-select/dist/js/bootstrap-select.js"></script>
    
    <!-- REVOLUTION JS FILES -->
	<script type="text/javascript" src="https://wtpower.io/assets/revolution-slider/revolution/js/jquery.themepunch.tools.min.js"></script>
	<script type="text/javascript" src="https://wtpower.io/assets/revolution-slider/revolution/js/jquery.themepunch.revolution.min.js"></script>

	<!-- SLIDER REVOLUTION 5.0 EXTENSIONS  (Load Extensions only on Local File Systems !  The following part can be removed on Server for On Demand Loading) -->	
	<script type="text/javascript" src="https://wtpower.io/assets/revolution-slider/revolution/js/extensions/revolution.extension.actions.min.js"></script>
	<script type="text/javascript" src="https://wtpower.io/assets/revolution-slider/revolution/js/extensions/revolution.extension.carousel.min.js"></script>
	<script type="text/javascript" src="https://wtpower.io/assets/revolution-slider/revolution/js/extensions/revolution.extension.kenburn.min.js"></script>
	<script type="text/javascript" src="https://wtpower.io/assets/revolution-slider/revolution/js/extensions/revolution.extension.layeranimation.min.js"></script>
	<script type="text/javascript" src="https://wtpower.io/assets/revolution-slider/revolution/js/extensions/revolution.extension.migration.min.js"></script>
	<script type="text/javascript" src="https://wtpower.io/assets/revolution-slider/revolution/js/extensions/revolution.extension.navigation.min.js"></script>
	<script type="text/javascript" src="https://wtpower.io/assets/revolution-slider/revolution/js/extensions/revolution.extension.parallax.min.js"></script>
	<script type="text/javascript" src="https://wtpower.io/assets/revolution-slider/revolution/js/extensions/revolution.extension.slideanims.min.js"></script>
	<script type="text/javascript" src="https://wtpower.io/assets/revolution-slider/revolution/js/extensions/revolution.extension.video.min.js"></script>
    <script src="https://wtpower.io/assets/js/revolution-slider.js" type="text/javascript"></script>
	
	
	<!-- Warehouse front end -->
	<script src="https://wtpower.io/assets/js/template.js"></script>
	


  <!-- jQuery library -->
  <script src="{{ asset($activeTemplateTrue.'/js/vendor/jquery-3.5.1.min.js') }}"></script>
  <!-- bootstrap js -->
  <script src="{{ asset($activeTemplateTrue.'/js/vendor/bootstrap.bundle.min.js') }}"></script>
  <!-- lightcase plugin -->
  <script src="{{ asset($activeTemplateTrue.'/js/vendor/lightcase.js') }}"></script>
  <!-- custom select js -->
  <script src="{{ asset($activeTemplateTrue.'/js/vendor/jquery.nice-select.min.js') }}"></script>
  <!-- slick slider js -->
  <script src="{{ asset($activeTemplateTrue.'/js/vendor/slick.min.js') }}"></script>
  <!-- scroll animation -->
  <script src="{{ asset($activeTemplateTrue.'/js/vendor/wow.min.js') }}"></script>
  <!-- dashboard custom js -->
  <script src="{{ asset($activeTemplateTrue.'/js/app.js')}}"></script>
  </body>

@stack('script-lib')


@include('admin.partials.notify')
@include('partials.plugins')
@stack('script')
<script type="text/javascript">
  (function($,document){
        "use strict";
        $(document).on('change', '#langSel', function () {
            var code = $(this).val();
            window.location.href = "{{url('/')}}/change-lang/"+code ;
        });
            
    })(jQuery,document);
</script>

	
</body>
</html>
