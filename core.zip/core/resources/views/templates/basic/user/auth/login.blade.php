
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="https://wtpower.io/energy/images/favicon.ico">

    <title>Dexel Solar - Log in </title>
  
	<!-- Vendors Style-->
	<link rel="stylesheet" href="https://wtpower.io/energy/css/vendors_css.css">
	  
	<!-- Style-->    
	<link rel="stylesheet" href="https://wtpower.io/energy/css/horizontal-menu.css"> 
	<link rel="stylesheet" href="https://wtpower.io/energy/css/style.css">
	<link rel="stylesheet" href="https://wtpower.io/energy/css/skin_color.css">	

</head>
	
<body class="hold-transition theme-primary bg-img" style="background-image: url(https://wtpower.io//assets/images/slider_bg.jpg)">
	
	<div class="container h-p100">
		<div class="row align-items-center justify-content-md-center h-p100">	
			
			<div class="col-12">
				<div class="row justify-content-center g-0">
					<div class="col-lg-5 col-md-5 col-12">
						<div class="bg-white rounded10 shadow-lg">
							<div class="content-top-agile p-20 pb-0">
								<h2 class="text-primary">Let's Get Started</h2>
								<p class="mb-0">Sign in to continue to dexelsolar.com</p>							
							</div>

							
							<div class="p-40">
					
			              <form class="action-form mt-50 loginForm" action="{{ route('user.login') }}" method="post">
                @csrf
                <div class="form-group">
                  <label>@lang('Username')</label>
                  <div class="input-group mb-2">
                    <div class="input-group-prepend">
                      <div class="input-group-text"><i class="las la-user"></i></div>
                    </div>
                    <input type="username" name="username" class="form-control" placeholder="@lang('Username')">
                  </div>
                </div><!-- form-group end -->
                <div class="form-group">
                  <label>@lang('Password')</label>
                  <div class="input-group mb-2">
                    <div class="input-group-prepend">
                      <div class="input-group-text"><i class="las la-key"></i></div>
                    </div>
                    <input type="password" name="password" class="form-control" placeholder="@lang('Password')">
                  </div>
                </div><!-- form-group end -->
                 <div class="form-group d-flex justify-content-center">
                  @php echo recaptcha() @endphp
                </div><!-- form-group end -->
                @include('partials.custom-captcha')
                 <p class="fog-pwd text-end"><a href="{{ route('user.password.request') }}">@lang('Forget password')</a></p>
                <div class="form-group text-center">
                  <button type="submit" class="btn btn-danger mt-10">@lang('Login Now')</button>
                
                </div>
              </form>

								<div class="text-center">
									<p class="mt-15 mb-0">Don't have an account? <a href="/register" class="text-warning ms-5">Sign Up</a></p>
								</div>	
							</div>						
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>


	<!-- Vendor JS -->
	<script src="https://wtpower.io/energy/js/vendors.min.js"></script>
	<script src="https://wtpower.io/energy/js/pages/chat-popup.js"></script>
    <script src="https://wtpower.io/energy/assets/icons/feather-icons/feather.min.js"></script>
    
<link rel="stylesheet" href="https://wtpower.io/assets/global/css/iziToast.min.css">
<script src="https://wtpower.io/assets/global/js/iziToast.min.js"></script>

<script>
    "use strict";
    function notify(status,message) {
        iziToast[status]({
            message: message,
            position: "topRight"
        });
    }
</script>
</body>
</html>
