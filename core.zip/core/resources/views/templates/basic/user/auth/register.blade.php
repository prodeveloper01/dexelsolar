
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="https://wtpower.io/energy/images/favicon.ico">

    <title>Dexel Solar - Signup </title>
  
	<!-- Vendors Style-->
	<link rel="stylesheet" href="https://wtpower.io/energy/css/vendors_css.css">
	  
	<!-- Style-->    
	<link rel="stylesheet" href="https://wtpower.io/energy/css/horizontal-menu.css"> 
	<link rel="stylesheet" href="https://wtpower.io/energy/css/style.css">
	<link rel="stylesheet" href="https://wtpower.io/energy/css/skin_color.css">	

</head>
	
<body class="hold-transition theme-primary bg-img" style="background-image: url(https://wtpower.io//assets/images/slider_bg.jpg)">
	
	<div class="container h-p100">
		<div class="row align-items-center justify-content-md-center h-p100">	
			
			<div class="col-12">
				<div class="row justify-content-center g-0">
					<div class="col-lg-5 col-md-5 col-12">
						<div class="bg-white rounded10 shadow-lg">
							<div class="content-top-agile p-20 pb-0">
								<h2 class="text-primary">Let's Get Started</h2>
								<p class="mb-0">Sign in to continue to dexelsolar.com</p>							
							</div>

							
							<div class="p-40">
					
			                         <form class="action-form mt-50 loginForm" action="{{ route('user.register') }}" method="post">
                @csrf
                @if($reference)
                <div class="form-group">
                  <label>@lang('Referred By')</label>
                  <input type="text" name="referral" class="form-control" autocomplete="off" autofocus="off" value="{{ $reference }}" readonly>
                </div><!-- form-group end -->
                @endif
                <div class="form-group">
                  <label>@lang('First Name')</label>
                  <input type="text" name="firstname" placeholder="@lang('First Name')" class="form-control" value="{{ old('firstname') }}">
                </div><!-- form-group end -->
                <div class="form-group">
                  <label>@lang('Last Name')</label>
                  <input type="text" name="lastname" placeholder="@lang('Last Name')" class="form-control" value="{{ old('lastname') }}">
                </div><!-- form-group end -->
                <div class="form-group">
                  <label>@lang('Email')</label>
                  <input type="email" name="email" placeholder="@lang('Email')" class="form-control" value="{{ old('email') }}">
                </div><!-- form-group end -->
                <div class="form-group">
                  <label>@lang('Mobile')</label>
                  <input type="text" name="mobile" placeholder="@lang('Mobile')" class="form-control" value="{{ old('mobile') }}">
                </div><!-- form-group end -->
                <div class="form-group">
                  <label>@lang('Username')</label>
                  <input type="text" name="username" placeholder="@lang('Username')" class="form-control" value="{{ old('username') }}">
                </div><!-- form-group end -->
                <div class="form-group">
                  <label>@lang('Password')</label>
                  <input type="password" name="password" placeholder="@lang('Password')" class="form-control">
                </div><!-- form-group end -->
                <div class="form-group">
                  <label>@lang('Re-type Password')</label>
                  <input type="password" name="password_confirmation" placeholder="@lang('Re-type Password')" class="form-control">
                </div><!-- form-group end -->
                <div class="form-group">
                    @php
                      $links = getContent('footer_link.element');
                    @endphp
                    <input checked type="checkbox" name="terms" required class="mr-2">
                    @lang('I agree with ')@foreach($links as $link) 
                    <a href="{{ route('links',[$link->id,slug($link->data_values->title)]) }}"> {{ __($link->data_values->title) }} </a>
                    @if(!$loop->last) , @endif @endforeach
                </div><!-- form-group end -->
                <div class="form-group d-flex justify-content-center">
                  @php echo recaptcha() @endphp
                </div><!-- form-group end -->
                @include('partials.custom-captcha')
                <div class="form-group text-center">
                  <button type="submit" class="btn btn-danger mt-10">@lang('Register Now')</button>
                  <p class="mt-20">@lang('Already have an account?') <a href="{{ route('user.login') }}">@lang('Login Now')</a></p>
                </div>
              </form>

							
							</div>						
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>


	<!-- Vendor JS -->
	<script src="https://wtpower.io/energy/js/vendors.min.js"></script>
	<script src="https://wtpower.io/energy/js/pages/chat-popup.js"></script>
    <script src="https://wtpower.io/energy/assets/icons/feather-icons/feather.min.js"></script>
    
<link rel="stylesheet" href="https://wtpower.io/assets/global/css/iziToast.min.css">
<script src="https://wtpower.io/assets/global/js/iziToast.min.js"></script>

<script>
    "use strict";
    function notify(status,message) {
        iziToast[status]({
            message: message,
            position: "topRight"
        });
    }
</script>
</body>
</html>
