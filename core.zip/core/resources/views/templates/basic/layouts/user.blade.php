
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
  
        <link rel="shortcut icon" type="image/png" href="{{ asset(imagePath()['logoIcon']['path'] .'/favicon.png') }}"/>
        <!-- bootstrap 4  -->
      <link rel="stylesheet" href="{{ asset($activeTemplateTrue.'/css/vendor/bootstrap.min.css') }}">
      <!-- fontawesome 5  -->
      <link rel="stylesheet" href="{{ asset($activeTemplateTrue.'/css/all.min.css') }}">
      <!-- line-awesome webfont -->
      <link rel="stylesheet" href="{{ asset($activeTemplateTrue.'/css/line-awesome.min.css') }}">
      <!-- image and videos view on page plugin -->
      <link rel="stylesheet" href="{{ asset($activeTemplateTrue.'/css/lightcase.css') }}">
      
      <link rel="stylesheet" href="{{ asset($activeTemplateTrue.'/css/vendor/animate.min.css') }}">
      <!-- custom select css -->
      <link rel="stylesheet" href="{{ asset($activeTemplateTrue.'/css/vendor/nice-select.css') }}">
      <!-- slick slider css -->
      <link rel="stylesheet" href="{{ asset($activeTemplateTrue.'/css/vendor/slick.css') }}">
      <!-- dashdoard main css -->
      <link rel="stylesheet" href="{{ asset($activeTemplateTrue.'/css/main.css') }}">
      <link rel="stylesheet" href="{{ asset($activeTemplateTrue.'/css/custom.css') }}">
        <link rel="stylesheet" href="{{ asset(asset($activeTemplateTrue)."/css/color.php?color1=$general->base_color&color2=$general->secondary_color") }}">
  <title>{{ $general->sitename($page_title) }}</title>
    
  <!-- Vendors Style-->
  <link rel="stylesheet" href="https://wtpower.io/energy/css/vendors_css.css">
    
  <!-- Style-->    
  <link rel="stylesheet" href="https://wtpower.io/energy/css/horizontal-menu.css"> 
  <link rel="stylesheet" href="https://wtpower.io/energy/css/style.css">
  <link rel="stylesheet" href="https://wtpower.io/energy/css/skin_color.css">
  
  <style>
      #methods .box-body .content-box{
           color: #fff;
            display: inline-block;
            margin: auto;
            background: #2f3478;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 12px 0px #000;
      }
      #methods .box-body .content-box p{
           color: #fff;
           font-size: 1.2rem;
           margin:0;
      }
      
      section.cmn-section {
          margin-top:10%!important;
      }
      
  </style>
     
  </head>

<body class="layout-top-nav light-skin theme-primary fixed">
  
<div class="wrapper">
  <div id="loader"></div>
  
  <header class="main-header">
    <div class="inside-header">
    <div class="d-flex align-items-center logo-box justify-content-start">
      <!-- Logo -->
      <a href="https://dexalsolar.paisakama.com/user/dashboard" class="logo">
        <!-- logo-->
        <div class="logo-lg">
          <span class="light-logo"><img src="{{ asset('assets/images/logoIcon/logo.png') }}" alt="logo"></span>
          <span class="dark-logo"><img src="{{ asset('assets/images/logoIcon/logo.png') }}" alt="logo"></span>
        </div>
      </a>  
    </div>  
    <!-- Header Navbar -->
    <nav class="navbar navbar-static-top">
      <!-- Sidebar toggle button-->
      <div class="app-menu">
      <ul class="header-megamenu nav">
        <li class="btn-group d-lg-inline-flex d-none">
          <div class="app-menu">

          </div>
        </li>
      </ul> 
      </div>

      <div class="navbar-custom-menu r-side">
      <ul class="nav navbar-nav"> 


        <!-- Notifications -->


        <!-- Control Sidebar Toggle Button -->

        <!-- User Account-->
          <li class="dropdown user user-menu">
            <a href="#" class="waves-effect waves-light dropdown-toggle w-auto l-h-12 bg-transparent py-0 no-shadow" data-bs-toggle="dropdown" title="User">
        <img src="https://wtpower.io/energy/images/avatar/avatar-1.png" class="avatar rounded-10 bg-primary-light h-40 w-40" alt="" />
            </a>
            <ul class="dropdown-menu animated flipInX">
              <li class="user-body">
         <a class="dropdown-item" href="https://dexalsolar.paisakama.com/user/profile-setting"><i class="ti-user text-muted me-2"></i> Profile</a>
         <div class="dropdown-divider"></div>
         
         <a class="dropdown-item" href="https://dexalsolar.paisakama.com/logout"><i class="ti-lock text-muted me-2"></i> Logout</a>
 
                                    </form>
                                    
              </li>
            </ul>
          </li></ul>

      </div>
    </nav>
    </div>
  </header>
  
  <nav class="main-nav" role="navigation">

    <!-- Mobile menu toggle button (hamburger/x icon) -->
    <input id="main-menu-state" type="checkbox" />
    <label class="main-menu-btn" for="main-menu-state">
    <span class="main-menu-btn-icon"></span> Toggle main menu visibility
    </label>

    <!-- Sample menu definition -->
    <ul id="main-menu" class="sm sm-blue"> 
    <li><a href="https://dexalsolar.paisakama.com/user/dashboard"><i data-feather="monitor"></i>Dashboard</a>
    </li>
    <li><a href="https://dexalsolar.paisakama.com/user/deposit"><i data-feather="layers"></i>Add Funds</a>
    </li>
    <li><a href="https://dexalsolar.paisakama.com/user/withdraw"><i data-feather="layout"></i>Cashout Funds</a>
    </li>
    <li><a href="https://dexalsolar.paisakama.com/user/plans"><i data-feather="lock"></i>Buy Energy</a>
    </li>
    <li><a href="https://dexalsolar.paisakama.com/user/energy"><i data-feather="lock"></i>Claim Energy</a>
    </li>
    <li><a href="https://dexalsolar.paisakama.com/user/referred-users"><i data-feather="edit"></i>My Referrals</a>      
    </li>
    <!--<li><a href="https://dexalsolar.paisakama.com/user/referred-users"><i data-feather="file-text"></i>My Chain</a>
    </li>-->
    <li><a href="https://dexalsolar.paisakama.com/user/deposit/history"><i data-feather="layout"></i>Fund History</a>
    </li>
    <li><a href="https://dexalsolar.paisakama.com/user/withdraw/history"><i data-feather="pie-chart"></i>Cashout History</a>
    </li>
    <li><a href="https://dexalsolar.paisakama.com/user/energy/clicks"><i data-feather="folder"></i>Earning History</a>
    </li>
    <!--<li><a href="https://dexalsolar.paisakama.com/user/commissions"><i data-feather="folder"></i>Comission History</a>
    </li>-->

    <li><a href="https://dexalsolar.paisakama.com/logout"><i data-feather="mail"></i>Logout</a></li>
                                                     

    </ul>
  </nav>
  <!-- Content Wrapper. Contains page content -->
   <div class="mt-100">
 @yield('content')
</div>
  <!-- /.content-wrapper -->

<link rel="stylesheet" href="https://wtpower.io/assets/global/css/iziToast.min.css">
<script src="https://wtpower.io/assets/global/js/iziToast.min.js"></script>

<script>
    "use strict";
    function notify(status,message) {
        iziToast[status]({
            message: message,
            position: "topRight"
        });
    }
</script>
<footer class="main-footer">
    <div class="pull-right d-none d-sm-inline-block">
        <ul class="nav nav-primary nav-dotted nav-dot-separated justify-content-center justify-content-md-end">
      <li class="nav-item">
      <a class="nav-link" href="javascript:void(0)">FAQ</a>
      </li>
      <li class="nav-item">
      <a class="nav-link" href="/index.php">Go Home</a>
      </li>
    </ul>
    </div>
    &copy; <script>document.write(new Date().getFullYear())</script> <a href="#">dexalsolar</a>. All Rights Reserved.
  </footer>

  <!-- Control Sidebar -->

  <!-- /.control-sidebar -->
  <!-- Add the sidebar's background. This div must be placed immediately after the control sidebar -->
  <div class="control-sidebar-bg"></div>
  
</div>
<!-- ./wrapper -->
  
  <!-- ./side demo panel -->

  <!-- Sidebar -->
    

  <!-- Page Content overlay -->
  
  
  <!-- Vendor JS -->
  <script src="https://wtpower.io/energy/js/vendors.min.js"></script>
  <script src="https://wtpower.io/energy/js/pages/chat-popup.js"></script>
    <script src="https://wtpower.io/energy/assets/icons/feather-icons/feather.min.js"></script> 

  <script src="https://wtpower.io/energy/assets/vendor_components/apexcharts-bundle/dist/apexcharts.js"></script>
  <script src="https://wtpower.io/energy/assets/vendor_components/progressbar.js-master/dist/progressbar.js"></script>
  <script>
  if(document.getElementById('e')){
    document.getElementById('e').value = new Date().toISOString().substring(0, 10);
  }
  </script>
  
  <!-- Deposito Admin App -->
  <script src="https://wtpower.io/energy/js/jquery.smartmenus.js"></script>
  <script src="https://wtpower.io/energy/js/menus.js"></script>
  <script src="https://wtpower.io/energy/js/template.js"></script>
  <!--<script src="https://wtpower.io/energy/js/pages/dashboard2.js"></script>-->
  

  <!-- jQuery library -->
  <script src="{{ asset($activeTemplateTrue.'/js/vendor/jquery-3.5.1.min.js') }}"></script>
  <!-- bootstrap js -->
  <script src="{{ asset($activeTemplateTrue.'/js/vendor/bootstrap.bundle.min.js') }}"></script>
  <!-- lightcase plugin -->
  <script src="{{ asset($activeTemplateTrue.'/js/vendor/lightcase.js') }}"></script>
  <!-- custom select js -->
  <script src="{{ asset($activeTemplateTrue.'/js/vendor/jquery.nice-select.min.js') }}"></script>
  <!-- slick slider js -->
  <script src="{{ asset($activeTemplateTrue.'/js/vendor/slick.min.js') }}"></script>
  <!-- scroll animation -->
  <script src="{{ asset($activeTemplateTrue.'/js/vendor/wow.min.js') }}"></script>
  <!-- dashboard custom js -->
  <script src="{{ asset($activeTemplateTrue.'/js/app.js')}}"></script>
  </body>

@stack('script-lib')


@include('admin.partials.notify')
@include('partials.plugins')
@stack('script')
<script type="text/javascript">
  (function($,document){
        "use strict";
        $(document).on('change', '#langSel', function () {
            var code = $(this).val();
            window.location.href = "{{url('/')}}/change-lang/"+code ;
        });
            
    })(jQuery,document);
</script>

</body>
</html>
