<section class="py-100 bg-white">
		<div class="container">
			<div class="row">
				<div class="col-lg-6 col-12 aos-init aos-animate" data-aos="fade-up">
					<div class="section-heading mb-30">
						<h3 class="heading fw-500">Dexal<span class="text-primary">Solar</span>, Green energy investment platform to earn daily highest earnings.</h3>
						<hr class="p-1 bg-primary w-100 ms-0">
					</div>
					<p class="fs-16 mb-4">Dexal Solar is making money by installing solar panels and turbines that we purchase using our investors investments and then we start making energy and we sell that energy back to goverment.</p>
					<p class="fs-16 mb-4">Fuel is distroying our planet's environment to protect it we need to harvest power from sun using solar panels and generate green energy with turbines.</p>
					<a href="/register" class="btn btn-primary">Join Now</a>
				</div>
				<div class="col-lg-6 col-12 aos-init aos-animate" data-aos="fade-up">
					<img src="/images/s1.png" class="img-fluid" alt="">
				</div>
			</div>
		</div>
	</section>
	<section class="py-100">
      <div class="container">
        <div class="row justify-content-center">
          <div class="col-md-6 col-12 text-center aos-init aos-animate" data-aos="fade-up">			  
			<div class="section-heading mb-30">
				<h2 class="heading fw-500">Services <br> <span class="text-primary"> We Provide</span></h2>
				<hr class="p-1 bg-primary w-100">
				<p class="fs-16">Through our experienced operations team we can handle various kind of supply chain operations and services</p>
			</div>
          </div>
        </div>
      </div>
      <div class="container">
        <div class="row">
            
        <div class="col-lg-3 col-md-6 text-center aos-init" data-aos="fade-up">
            <div class="service-box mt-5">
              <br>    
              <img src="https://wtpower.io/assets/images/spec_1.png" alt="">
              <br><br>
              <h4 class="mb-20 px-30">Solar System</h4>
			  <a href="/user/register" class="btn btn-primary mb-30">Buy Energy</a>
            </div>
          </div>
          
        <div class="col-lg-3 col-md-6 text-center aos-init" data-aos="fade-up">
            <div class="service-box mt-5">
              <br>    
              <img src="https://wtpower.io/assets/images/spec_2.png" alt="">
              <br><br>
              <h4 class="mb-20 px-30">Solar Pv System</h4>
			  <a href="/user/register" class="btn btn-primary mb-30">Buy Energy</a>
            </div>
          </div>
          
        <div class="col-lg-3 col-md-6 text-center aos-init" data-aos="fade-up">
            <div class="service-box mt-5">
              <br>    
              <img src="https://wtpower.io/assets/images/spec_3.png" alt="">
              <br><br>
              <h4 class="mb-20 px-30">Wind Generators</h4>
			  <a href="/user/register" class="btn btn-primary mb-30">Buy Energy</a>
            </div>
          </div>
          
        <div class="col-lg-3 col-md-6 text-center aos-init" data-aos="fade-up">
            <div class="service-box mt-5">
              <br>    
              <img src="https://wtpower.io/assets/images/spec_4.png" alt="">
              <br><br>
              <h4 class="mb-20 px-30">Alternative Energy</h4>
			  <a href="/user/register" class="btn btn-primary mb-30">Buy Energy</a>
            </div>
          </div>
          
          

		            
        </div>
      </div>
    </section>