

<?php $__env->startSection('panel'); ?>
<div class="row">

    <div class="col-lg-12">
        <div class="card">
            <div class="table-responsive--sm">
                <table class="table table--light style--two">
                    <thead>
                        <tr>
                            <th scope="col"><?php echo app('translator')->get('Name'); ?></th>
                            <th scope="col"><?php echo app('translator')->get('Price'); ?></th>
                            <th scope="col"><?php echo app('translator')->get('Daily Earning'); ?></th>
                            <th scope="col"><?php echo app('translator')->get('Referral Commission'); ?></th>
                            <th scope="col"><?php echo app('translator')->get('status'); ?></th>
                            <th scope="col"><?php echo app('translator')->get('Action'); ?></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $plans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $plan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td data-label="<?php echo app('translator')->get('Name'); ?>"><?php echo e($plan->name); ?></td>
                            <td data-label="<?php echo app('translator')->get('Price'); ?>" class="font-weight-bold"><?php echo e($plan->price+0); ?> <?php echo e($general->cur_text); ?></td>     

                            <td data-label="<?php echo app('translator')->get('Limit/Day'); ?>"><?php echo app('translator')->get('Daily Earning    '); ?><?php echo e($plan->daily_limit); ?> </td>
                            <td data-label="<?php echo app('translator')->get('Referral Commission'); ?>"><?php echo app('translator')->get('up to'); ?> <span class="font-weight-bold text-primary px-3"><?php echo e($plan->ref_level); ?> </span><?php echo app('translator')->get('level'); ?></td>
                            <td data-label="<?php echo app('translator')->get('Status'); ?>">
                                    <?php if($plan->status == 1): ?>
                                <span class="badge badge--success font-weight-normal text--small">
                                    <?php echo app('translator')->get('active'); ?>
                                </span>
                                    <?php else: ?>
                                    <span class="badge badge--danger font-weight-normal text--small">
                                    <?php echo app('translator')->get('inactive'); ?>
                                </span>

                                    <?php endif; ?>
                                </span>
                            </td>
                            <td data-label="<?php echo app('translator')->get('Action'); ?>"> 
                                <button class="icon-btn editBtn" data-id="<?php echo e($plan->id); ?>" data-name="<?php echo e($plan->name); ?>" data-price="<?php echo e($plan->price+0); ?>" data-daily_limit="<?php echo e($plan->daily_limit); ?>"  data-status="<?php echo e($plan->status); ?>" data-ref_level="<?php echo e($plan->ref_level); ?>" data-act="Edit">
                                    <i class="la la-pencil"></i>
                                </button>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td class="text-muted text-center" colspan="100%"><?php echo e($empty_message); ?></td>
                        </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
            <div class="card-footer py-4">
                <nav aria-label="...">
                    <?php echo e($plans->links('admin.partials.paginate')); ?>

                </nav>
            </div>
        </div>
    </div>
</div>


<div id="editModal" class="modal fade" tabindex="-1" role="dialog">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title"><span class="act"></span> <?php echo app('translator')->get('Membership Plan'); ?></h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <form action="<?php echo e(route('admin.plan.update')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="id">
                <div class="modal-body">

                    <div class="form-group">
                        <label for="name"><strong><?php echo app('translator')->get('Name'); ?> :</strong> </label>
                        <input type="text" class="form-control" name="name" placeholder="<?php echo app('translator')->get('Plan Name'); ?>" required>
                    </div>
                    <div class="form-group">
                        <label for="price"><strong><?php echo app('translator')->get('Price'); ?> :</strong> </label>
                        <div class="input-group mb-3">
                            <input type="text" class="form-control has-append" name="price" placeholder="<?php echo app('translator')->get('Price of Plan'); ?>" required>
                            <div class="input-group-append">
                                <div class="input-group-text"><?php echo e($general->cur_text); ?></div>
                            </div>
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="daily_limit"><strong><?php echo app('translator')->get('Daily Earning'); ?> :</strong></label>
                        <input type="number" class="form-control" name="daily_limit" placeholder="<?php echo app('translator')->get('Daily Earning'); ?>" required>
                    </div>
                    <div class="form-group">
                        <label for="details"><strong><?php echo app('translator')->get('Referral Commission'); ?> :</strong> </label>
                        <select name="ref_level" class="form-control" required>
                            <option value="0"> <?php echo app('translator')->get('NO Referral Commission'); ?></option>
                            <?php $__currentLoopData = $refs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($v->level); ?>"> <?php echo app('translator')->get('Up to'); ?> <?php echo e($v->level); ?>  <?php echo app('translator')->get('Level'); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>

                    </div>
                    <div class="form-group">
                        <label for="status"><strong><?php echo app('translator')->get('Status :'); ?></strong> </label>
                        <input type="checkbox" data-height="46" data-onstyle="success" data-offstyle="danger" data-on="Active" data-off="Inactive" data-width="100%"  data-toggle="toggle" name="status">
                    </div>

                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-dark" data-dismiss="modal"><?php echo app('translator')->get('Close'); ?></button>
                    <button type="submit" class="btn btn--primary"><?php echo app('translator')->get('Submit'); ?></button>
                </div>
            </form>
        </div>
    </div>
</div>


<?php $__env->stopSection(); ?>

<?php $__env->startPush('breadcrumb-plugins'); ?>
<button class="icon-btn editBtn" data-id="0" data-act="Add"><i class="fa fa-fw fa-plus"></i>Add New</button>
<?php $__env->stopPush(); ?>


<?php $__env->startPush('script'); ?>
<script>
    (function($){
        "use strict";
        $('.editBtn').on('click', function() {
            var modal = $('#editModal');
            modal.find('.act').text($(this).data('act'));
            modal.find('input[name=id]').val($(this).data('id'));
            modal.find('input[name=name]').val($(this).data('name'));
            modal.find('input[name=price]').val($(this).data('price'));
            modal.find('input[name=daily_limit]').val($(this).data('daily_limit'));
            modal.find('input[name=status]').bootstrapToggle($(this).data('status') == 1 ? 'on' : 'off');
            modal.find('select[name=ref_level]').val($(this).data('ref_level'));
            modal.modal('show');
        });
    })(jQuery);
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/paisakama/dexalsolar.paisakama.com/core/resources/views/admin/plans.blade.php ENDPATH**/ ?>