
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="https://wtpower.io/energy/images/favicon.ico">

    <title>Dexel Solar - Signup </title>
  
	<!-- Vendors Style-->
	<link rel="stylesheet" href="https://wtpower.io/energy/css/vendors_css.css">
	  
	<!-- Style-->    
	<link rel="stylesheet" href="https://wtpower.io/energy/css/horizontal-menu.css"> 
	<link rel="stylesheet" href="https://wtpower.io/energy/css/style.css">
	<link rel="stylesheet" href="https://wtpower.io/energy/css/skin_color.css">	

</head>
	
<body class="hold-transition theme-primary bg-img" style="background-image: url(https://wtpower.io//assets/images/slider_bg.jpg)">
	
	<div class="container h-p100">
		<div class="row align-items-center justify-content-md-center h-p100">	
			
			<div class="col-12">
				<div class="row justify-content-center g-0">
					<div class="col-lg-5 col-md-5 col-12">
						<div class="bg-white rounded10 shadow-lg">
							<div class="content-top-agile p-20 pb-0">
								<h2 class="text-primary">Let's Get Started</h2>
								<p class="mb-0">Sign in to continue to dexelsolar.com</p>							
							</div>

							
							<div class="p-40">
					
			                         <form class="action-form mt-50 loginForm" action="<?php echo e(route('user.register')); ?>" method="post">
                <?php echo csrf_field(); ?>
                <?php if($reference): ?>
                <div class="form-group">
                  <label><?php echo app('translator')->get('Referred By'); ?></label>
                  <input type="text" name="referral" class="form-control" autocomplete="off" autofocus="off" value="<?php echo e($reference); ?>" readonly>
                </div><!-- form-group end -->
                <?php endif; ?>
                <div class="form-group">
                  <label><?php echo app('translator')->get('First Name'); ?></label>
                  <input type="text" name="firstname" placeholder="<?php echo app('translator')->get('First Name'); ?>" class="form-control" value="<?php echo e(old('firstname')); ?>">
                </div><!-- form-group end -->
                <div class="form-group">
                  <label><?php echo app('translator')->get('Last Name'); ?></label>
                  <input type="text" name="lastname" placeholder="<?php echo app('translator')->get('Last Name'); ?>" class="form-control" value="<?php echo e(old('lastname')); ?>">
                </div><!-- form-group end -->
                <div class="form-group">
                  <label><?php echo app('translator')->get('Email'); ?></label>
                  <input type="email" name="email" placeholder="<?php echo app('translator')->get('Email'); ?>" class="form-control" value="<?php echo e(old('email')); ?>">
                </div><!-- form-group end -->
                <div class="form-group">
                  <label><?php echo app('translator')->get('Mobile'); ?></label>
                  <input type="text" name="mobile" placeholder="<?php echo app('translator')->get('Mobile'); ?>" class="form-control" value="<?php echo e(old('mobile')); ?>">
                </div><!-- form-group end -->
                <div class="form-group">
                  <label><?php echo app('translator')->get('Username'); ?></label>
                  <input type="text" name="username" placeholder="<?php echo app('translator')->get('Username'); ?>" class="form-control" value="<?php echo e(old('username')); ?>">
                </div><!-- form-group end -->
                <div class="form-group">
                  <label><?php echo app('translator')->get('Password'); ?></label>
                  <input type="password" name="password" placeholder="<?php echo app('translator')->get('Password'); ?>" class="form-control">
                </div><!-- form-group end -->
                <div class="form-group">
                  <label><?php echo app('translator')->get('Re-type Password'); ?></label>
                  <input type="password" name="password_confirmation" placeholder="<?php echo app('translator')->get('Re-type Password'); ?>" class="form-control">
                </div><!-- form-group end -->
                <div class="form-group">
                    <?php
                      $links = getContent('footer_link.element');
                    ?>
                    <input checked type="checkbox" name="terms" required class="mr-2">
                    <?php echo app('translator')->get('I agree with '); ?><?php $__currentLoopData = $links; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $link): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                    <a href="<?php echo e(route('links',[$link->id,slug($link->data_values->title)])); ?>"> <?php echo e(__($link->data_values->title)); ?> </a>
                    <?php if(!$loop->last): ?> , <?php endif; ?> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div><!-- form-group end -->
                <div class="form-group d-flex justify-content-center">
                  <?php echo recaptcha() ?>
                </div><!-- form-group end -->
                <?php echo $__env->make('partials.custom-captcha', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <div class="form-group text-center">
                  <button type="submit" class="btn btn-danger mt-10"><?php echo app('translator')->get('Register Now'); ?></button>
                  <p class="mt-20"><?php echo app('translator')->get('Already have an account?'); ?> <a href="<?php echo e(route('user.login')); ?>"><?php echo app('translator')->get('Login Now'); ?></a></p>
                </div>
              </form>

							
							</div>						
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>


	<!-- Vendor JS -->
	<script src="https://wtpower.io/energy/js/vendors.min.js"></script>
	<script src="https://wtpower.io/energy/js/pages/chat-popup.js"></script>
    <script src="https://wtpower.io/energy/assets/icons/feather-icons/feather.min.js"></script>
    
<link rel="stylesheet" href="https://wtpower.io/assets/global/css/iziToast.min.css">
<script src="https://wtpower.io/assets/global/js/iziToast.min.js"></script>

<script>
    "use strict";
    function notify(status,message) {
        iziToast[status]({
            message: message,
            position: "topRight"
        });
    }
</script>
</body>
</html>
<?php /**PATH /home/paisakama/dexalsolar.paisakama.com/core/resources/views/templates/basic/user/auth/register.blade.php ENDPATH**/ ?>