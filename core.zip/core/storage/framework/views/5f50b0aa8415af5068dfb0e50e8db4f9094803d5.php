

<?php $__env->startSection('content'); ?>
<?php echo $__env->make($activeTemplate.'breadcrumb', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<section class="cmn-section">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="form-group">
                    <label><?php echo app('translator')->get('Referral Link'); ?></label>
                    <div class="input-group">
                        <input type="text" value="<?php echo e(route('user.refer.register',$user->username)); ?>"
                        class="form-control form-control-lg" id="referralURL"
                        readonly>
                        <div class="input-group-append copytextDiv">
                            <span class="input-group-text copytext" id="copyBoard"> <i class="fa fa-copy"></i> </span>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-3 mb-30">
                <?php if($user->plan): ?>
                    <p class="text-center mb-2 font-weight-bold"><?php echo app('translator')->get('Your Current Plan '); ?><span class="text-success"><?php echo e(__($user->plan->name)); ?></span></p>
                    <p class="text-center mb-2 font-weight-bold"><?php echo app('translator')->get('Referral Level Up To '); ?><span class="text-danger"><?php echo e(__($user->plan->ref_level)); ?> <?php echo app('translator')->get('Level'); ?></span></p>
                <?php else: ?>
                    <p class="text-center mb-2 font-weight-bold"><?php echo app('translator')->get('You have no plan'); ?></p>
                <?php endif; ?>
                <?php if($user->refBy): ?>
                    <p class="text-center mb-2 font-weight-bold"><?php echo app('translator')->get('My Referral '); ?> <span class="text-primary"><?php echo e(__($user->refBy->username)); ?></span></p>
                <?php endif; ?>
                <ul class="list-group">
                    <?php $__empty_1 = true; $__currentLoopData = $levels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $level): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <li class="list-group-item <?php if($user->plan && $user->plan->ref_level >= $level->level): ?> bg-success-custom brd-success-custom <?php endif; ?>"><span class="float-left"><?php echo app('translator')->get('#Level '); ?><?php echo e(__($level->level)); ?></span><strong class="float-right"><?php echo e(__($level->percent)); ?> %</strong></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <li class="list-group-item text-center"><?php echo app('translator')->get('No level found'); ?></li>
                    <?php endif; ?>
                </ul>
            </div>
            <div class="col-md-9 mb-30">
                <div class="card table-card">
                    <div class="card-body p-0">
                        <div class="table-responsive--sm">
                            <table class="table table-striped">
                                <thead class="thead-dark">
                                <tr>
                                    <th><?php echo app('translator')->get('Full Name'); ?></th>
                                    <th><?php echo app('translator')->get('User Name'); ?></th>
                                    <th><?php echo app('translator')->get('Email'); ?></th>
                                    <th><?php echo app('translator')->get('Mobile'); ?></th>
                                    <th><?php echo app('translator')->get('Plan'); ?></th>
                                </tr>
                                </thead>
                                <tbody>
                                <?php if(count($refUsers) >0): ?>
                                    <?php $__empty_1 = true; $__currentLoopData = $refUsers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $log): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <tr>
                                        <td data-label="<?php echo app('translator')->get('Full Name'); ?>"><?php echo e(__($log->fullname)); ?></td>
                                        <td data-label="<?php echo app('translator')->get('User Name'); ?>"><?php echo e(__($log->username)); ?></td>
                                        <td data-label="<?php echo app('translator')->get('Email'); ?>"><?php echo e($log->email); ?></td>
                                        <td data-label="<?php echo app('translator')->get('Phone'); ?>"><?php echo e($log->mobile); ?></td>
                                        <td data-label="<?php echo app('translator')->get('Plan'); ?>"><?php echo e(__($log->plan ? $log->plan->name : "No Plan")); ?></td>
                                    </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php else: ?>
                                            <tr>
                                                <td colspan="100%" class="text-center"> <?php echo app('translator')->get('No results found'); ?>!</td>
                                            </tr>
                                        <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
                <?php echo e($refUsers->links($activeTemplate.'paginate')); ?>

            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('style'); ?>
<style type="text/css">
    .copytextDiv{
        border:1px solid #0000007a;
        cursor: pointer;
    }
    #referralURL{
        border-right: 1px solid #0000007a;
    }
    .bg-success-custom{
        background-color: #28a7456e!important;
    }
    .brd-success-custom{
        border: 1px dashed #28a745;   
    }
</style>
<?php $__env->stopPush(); ?>
<?php $__env->startPush('script'); ?>
<script type="text/javascript">
    (function ($) {
        "use strict";
        $('#copyBoard').click(function(){
            var copyText = document.getElementById("referralURL");
            copyText.select();
            copyText.setSelectionRange(0, 99999);
            /*For mobile devices*/
            document.execCommand("copy");
            iziToast.success({message: "Copied: " + copyText.value, position: "topRight"});
        });
    })(jQuery);
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make($activeTemplate .'layouts.user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/paisakama/dexalsolar.paisakama.com/core/resources/views/templates/basic/user/referred.blade.php ENDPATH**/ ?>