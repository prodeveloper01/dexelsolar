<?php $__env->startSection('content'); ?>
<?php echo $__env->make($activeTemplate.'breadcrumb', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<section class="cmn-section">
    <div class="container">
        <div class="row mb-60-80">
            <div class="col-md-12 mb-30">
                <div class="card table-card">
                    <div class="card-body p-0">
                        
                        <div class="table-responsive--sm">
                            <table class="table table-striped">
                                <thead class="thead-dark">
                                <tr>
                                    <th scope="col"><?php echo app('translator')->get('Transaction ID'); ?></th>
                                    <th scope="col"><?php echo app('translator')->get('Amount'); ?></th>
                                    <th scope="col"><?php echo app('translator')->get('Remaining Balance'); ?></th>
                                    <th scope="col"><?php echo app('translator')->get('Details'); ?></th>
                                    <th scope="col"><?php echo app('translator')->get('Date'); ?></th>

                                </tr>
                                </thead>
                                <tbody>
                                <?php if(count($logs) >0): ?>
                                    <?php $__currentLoopData = $logs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k=>$data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td data-label="<?php echo app('translator')->get('Transaction Id'); ?>"><?php echo e($data->trx); ?></td>
                                            <td data-label="<?php echo app('translator')->get('Amount'); ?>">
                                                <strong <?php if($data->trx_type == '+'): ?> class="text-success" <?php else: ?> class="text-danger" <?php endif; ?>> <?php echo e(($data->trx_type == '+') ? '+':'-'); ?> <?php echo e(getAmount($data->amount)); ?> <?php echo e($general->cur_text); ?></strong>
                                            </td>
                                            <td data-label="<?php echo app('translator')->get('Remaining Balance'); ?>">
                                                <strong class="text-info"><?php echo e(getAmount($data->post_balance)); ?> <?php echo e(__($general->cur_text)); ?></strong>
                                            </td>
                                            <td data-label="<?php echo app('translator')->get('Details'); ?>"><?php echo e(__($data->details)); ?></td>
                                            <td data-label="<?php echo app('translator')->get('Date'); ?>"><?php echo e(date('d M, Y', strtotime($data->created_at))); ?></td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php else: ?>
                                    <tr>
                                        <td colspan="100%" class="text-center"> <?php echo app('translator')->get('No results found'); ?>!</td>
                                    </tr>
                                <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>

                <?php echo e($logs->links($activeTemplate.'paginate')); ?>

            </div>
        </div>
    </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make($activeTemplate .'layouts.user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/paisakama/dexalsolar.paisakama.com/core/resources/views/templates/basic/user/transactions.blade.php ENDPATH**/ ?>