<?php $__env->startSection('panel'); ?>
<div class="row">

    <div class="col-lg-12">
        <div class="card">
            <div class="table-responsive--sm">
                <table class="table table--light style--two">
                    <thead>
                        <tr>
                            <th scope="col"><?php echo app('translator')->get('Title'); ?></th>
                            <th scope="col"><?php echo app('translator')->get('Type'); ?></th>
                            <th scope="col"><?php echo app('translator')->get('Duration'); ?></th>
                            <th scope="col"><?php echo app('translator')->get('Maximum View'); ?></th>
                            <th scope="col"><?php echo app('translator')->get('Viewed'); ?></th>
                            <th scope="col"><?php echo app('translator')->get('Remain'); ?></th>
                            <th scope="col"><?php echo app('translator')->get('Amount'); ?></th>
                            <th scope="col"><?php echo app('translator')->get('Status'); ?></th>
                            <th scope="col"><?php echo app('translator')->get('Action'); ?></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $ptcs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ptc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td data-label="<?php echo app('translator')->get('Title'); ?>"><?php echo e(description_shortener($ptc->title,20)); ?></td>
                            <td data-label="<?php echo app('translator')->get('Type'); ?>">
                                    <?php if($ptc->ads_type == 1): ?>
                                        <span class="font-weight-normal text--small badge badge--success"><i class="fa fa-link"></i> <?php echo app('translator')->get('URL'); ?></span>
                                    <?php elseif($ptc->ads_type == 2): ?>
                                        <span class="font-weight-normal text--small badge badge--dark"><i class="fa fa-image"></i> <?php echo app('translator')->get('Image'); ?></span>
                                    <?php else: ?>
                                        <span class="font-weight-normal text--small badge badge--primary"><i class="fa fa-code"></i> <?php echo app('translator')->get('Script'); ?></span>
                                    <?php endif; ?>
                            </td>
                            <td data-label="<?php echo app('translator')->get('Duration'); ?>"><?php echo e($ptc->duration); ?> <?php echo app('translator')->get('Sec'); ?></td>
                            <td data-label="<?php echo app('translator')->get('Maximum View'); ?>"><?php echo e($ptc->max_show); ?></td>
                            <td data-label="<?php echo app('translator')->get('Viewed'); ?>"><?php echo e($ptc->showed); ?></td>
                            <td data-label="<?php echo app('translator')->get('Remain'); ?>"><?php echo e($ptc->remain); ?></td>


                            <td data-label="<?php echo app('translator')->get('Amount'); ?>" class="font-weight-bold"><?php echo e($ptc->amount+0); ?> <?php echo e($general->cur_text); ?></td>     

                            <td data-label="<?php echo app('translator')->get('Status'); ?>">
                                <?php if($ptc->status == 1): ?>
                                    <span class="font-weight-normal text--small badge badge--success"><?php echo app('translator')->get('active'); ?></span>
                                <?php else: ?>
                                    <span class="font-weight-normal text--small badge badge--warning"><?php echo app('translator')->get('inactive'); ?></span>
                                <?php endif; ?>
                            </td>
                            <td data-label="<?php echo app('translator')->get('Action'); ?>"><a class="icon-btn" href="<?php echo e(route('admin.ptc.edit',$ptc->id)); ?>"><i class="la la-pen"></i></a></td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td class="text-muted text-center" colspan="100%"><?php echo e($empty_message); ?></td>
                        </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
            <div class="card-footer py-4">
                <nav aria-label="...">
                    <?php echo e($ptcs->links('admin.partials.paginate')); ?>

                </nav>
            </div>
        </div>
    </div>
</div>


<?php $__env->stopSection(); ?>

<?php $__env->startPush('breadcrumb-plugins'); ?>
        <a class="icon-btn" href="<?php echo e(route('admin.ptc.create')); ?>"><i class="fa fa-fw fa-plus"></i><?php echo app('translator')->get('Add New'); ?></a>
<?php $__env->stopPush(); ?>


<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/paisakama/dexalsolar.paisakama.com/core/resources/views/admin/ptc/index.blade.php ENDPATH**/ ?>