<?php $__env->startSection('content'); ?>
<?php echo $__env->make($activeTemplate.'breadcrumb', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<section class="cmn-section">
   <div class="container">
       <div class="row">
           <div class="col-md-12">
            <div class="card table-card">
              <div class="card-body p-o">
                   <div class="table-responsive--sm">
                       <table class="table table-striped">
                           <thead class="thead-dark">
                           <tr>
                               <th scope="col"><?php echo app('translator')->get('Transaction ID'); ?></th>
                               <th scope="col"><?php echo app('translator')->get('Gateway'); ?></th>
                               <th scope="col"><?php echo app('translator')->get('Amount'); ?></th>
                               <th scope="col"><?php echo app('translator')->get('Charge'); ?></th>
                               <th scope="col"><?php echo app('translator')->get('After Charge'); ?></th>
                               <th scope="col"><?php echo app('translator')->get('Rate'); ?></th>
                               <th scope="col"><?php echo app('translator')->get('Receivable'); ?></th>
                               <th scope="col"><?php echo app('translator')->get('Status'); ?></th>
                               <th scope="col"><?php echo app('translator')->get('Time'); ?></th>
                           </tr>
                           </thead>
                           <tbody>
                    
                               <?php $__empty_1 = true; $__currentLoopData = $withdraws; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k=>$data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                   <tr>
                                       <td data-label="<?php echo app('translator')->get('Transaction Id'); ?>"><?php echo e($data->trx); ?></td>
                                       <td data-label="<?php echo app('translator')->get('Gateway'); ?>"><?php echo e($data->method->name); ?></td>
                                       <td data-label="<?php echo app('translator')->get('Amount'); ?>">
                                           <strong><?php echo e(getAmount($data->amount)); ?> <?php echo e($general->cur_text); ?></strong>
                                       </td>
                                       <td data-label="<?php echo app('translator')->get('Charge'); ?>" class="text-danger">
                                           <?php echo e(getAmount($data->charge)); ?> <?php echo e($general->cur_text); ?>

                                       </td>
                                       <td data-label="<?php echo app('translator')->get('After Charge'); ?>">
                                           <?php echo e(getAmount($data->after_charge)); ?> <?php echo e($general->cur_text); ?>

                                       </td>
                                       <td data-label="<?php echo app('translator')->get('Rate'); ?>">
                                           <?php echo e($data->rate +0); ?>

                                       </td>
                                       <td data-label="<?php echo app('translator')->get('Receivable'); ?>"  class="text-success">
                                           <strong><?php echo e(getAmount($data->final_amount)); ?> <?php echo e($data->currency); ?></strong>
                                       </td>
                                       <td data-label="<?php echo app('translator')->get('Status'); ?>">
                                           <?php if($data->status == 2): ?>
                                               <span class="badge badge-warning"><?php echo app('translator')->get('Pending'); ?></span>
                                           <?php elseif($data->status == 1): ?>
                                               <span class="badge badge-success"><?php echo app('translator')->get('Completed'); ?></span>
                                               <button class="btn btn-sm btn-info infoBtn" data-info="<?php echo e($data->admin_feedback); ?>"><?php echo app('translator')->get('information'); ?></button>
                                           <?php elseif($data->status == 3): ?>
                                               <span class="badge badge-danger"><?php echo app('translator')->get('Rejected'); ?></span>
                                               <button class="btn btn-sm btn-info infoBtn" data-info="<?php echo e($data->admin_feedback); ?>"><?php echo app('translator')->get('information'); ?></button>
                                           <?php endif; ?>

                                       </td>
                                       <td data-label="<?php echo app('translator')->get('Time'); ?>">
                                           <i class="fa fa-calendar"></i> <?php echo e(date('d M, Y ', strtotime($data->created_at))); ?>

                                           <span class="pl-1"></span> <?php echo e(date('h:i A', strtotime($data->created_at))); ?>

                                       </td>
                                   </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td class="text-muted text-center" colspan="100%"><?php echo e($empty_message); ?></td>
                            </tr>
                            <?php endif; ?>
                           </tbody>
                       </table>
                   </div>
                
              </div>
            </div>

               <?php echo e($withdraws->links($activeTemplate.'paginate')); ?>

           </div>
       </div>
   </div>
</section>


<!-- Modal -->
    <div class="modal fade" id="infoModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
         aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <strong class="modal-title method-name" id="exampleModalLabel"><?php echo app('translator')->get('Information Modal'); ?></strong>
                    <a href="javascript:void(0)" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </a>
                </div>
                <div class="modal-body">
                  <p></p>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('script'); ?>
<script type="text/javascript">
  (function ($) {
     "use strict";
      $('.infoBtn').click(function(){
        var modal = $('#infoModal');
        modal.find('p').html($(this).data('info'));
        modal.modal('show');
      });
  })(jQuery);
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make($activeTemplate .'layouts.user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/paisakama/dexalsolar.paisakama.com/core/resources/views/templates/basic/user/withdraw/log.blade.php ENDPATH**/ ?>