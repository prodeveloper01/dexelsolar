<?php $__env->startSection('content'); ?>
<?php echo $__env->make($activeTemplate.'breadcrumb', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<section class="cmn-section">
    <div class="container">
    <section class="content">

	<div class="container-full">
        <!-- Main content -->

<div class="col-12">
					<div class="box">
						<div class="box-body">
							<div class="table-responsive">
							    
								<table class="table b-1 border-success">
									<thead class="bg-success">
                            <tr>
                                <th>Date</th>
                                <th>Energy Claims</th>
                                <th>Total Earn</th>
                                </tr> 

									</thead>
									<tbody>
									    
                            							<tr>
							<td colspan="100%" class="text-center">Data not found</td>
							</tr>
                                                        
									</tbody>
								</table>
								
                    
							
							</div>
						</div>
					</div>
				</div>

        <!-- /.content -->
      </div>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make($activeTemplate .'layouts.user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/paisakama/dexalsolar.paisakama.com/core/resources/views/templates/basic/user/energyclicks.blade.php ENDPATH**/ ?>