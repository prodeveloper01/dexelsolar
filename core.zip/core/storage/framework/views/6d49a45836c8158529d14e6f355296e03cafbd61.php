<?php $__env->startSection('panel'); ?>

<div class="row">

    <div class="col-lg-12">
        <div class="card b-radius--10 ">
            <div class="card-body p-0">
                <div class="table-responsive--sm table-responsive">
                    <table class="table table--light style--two">
                        <thead>
                        <tr>
                            <th scope="col"><?php echo app('translator')->get('Date'); ?></th>
                            <th scope="col"><?php echo app('translator')->get('Trx Number'); ?></th>
                            <th scope="col"><?php echo app('translator')->get('Username'); ?></th>
                            <th scope="col"><?php echo app('translator')->get('Method'); ?></th>
                            <th scope="col"><?php echo app('translator')->get('Amount'); ?></th>
                            <th scope="col"><?php echo app('translator')->get('Charge'); ?></th>
                            <th scope="col"><?php echo app('translator')->get('After Charge'); ?></th>
                            <th scope="col"><?php echo app('translator')->get('Rate'); ?></th>
                            <th scope="col"><?php echo app('translator')->get('Payable'); ?></th>

                            <?php if(request()->routeIs('admin.deposit.pending') || request()->routeIs('admin.deposit.approved')): ?>
                                <th scope="col"><?php echo app('translator')->get('Action'); ?></th>

                            <?php elseif(request()->routeIs('admin.deposit.list') || request()->routeIs('admin.deposit.search') || request()->routeIs('admin.users.deposits')): ?>
                                <th scope="col"><?php echo app('translator')->get('Status'); ?></th>
                            <?php endif; ?>
                        </tr>
                        </thead>
                        <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $deposits; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $deposit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <?php
                                $details = ($deposit->detail != null) ? json_encode($deposit->detail) : null;
                            ?>

                            <tr>
                                <td data-label="<?php echo app('translator')->get('Date'); ?>"> <?php echo e(showDateTime($deposit->created_at)); ?></td>
                                <td data-label="<?php echo app('translator')->get('Trx Number'); ?>" class="font-weight-bold text-uppercase"><?php echo e($deposit->trx); ?></td>
                                <td data-label="<?php echo app('translator')->get('Username'); ?>"><a href="<?php echo e(route('admin.users.detail', $deposit->user_id)); ?>"><?php echo e($deposit->user->username); ?></a></td>
                                <td data-label="<?php echo app('translator')->get('Method'); ?>"><?php echo e($deposit->gateway->name); ?></td>
                                <td data-label="<?php echo app('translator')->get('Amount'); ?>" class="font-weight-bold"><?php echo e(getAmount($deposit->amount )); ?> <?php echo e($general->cur_text); ?></td>
                                <td data-label="<?php echo app('translator')->get('Charge'); ?>" class="text-success"><?php echo e(getAmount($deposit->charge)); ?> <?php echo e($general->cur_text); ?></td>
                                <td data-label="<?php echo app('translator')->get('After Charge'); ?>"> <?php echo e(getAmount($deposit->amount+$deposit->charge)); ?> <?php echo e($general->cur_text); ?></td>
                                <td data-label="<?php echo app('translator')->get('Rate'); ?>"> <?php echo e(getAmount($deposit->rate)); ?> <?php echo e($deposit->method_currency); ?></td>
                                <td data-label="<?php echo app('translator')->get('Payable'); ?>" class="font-weight-bold"><?php echo e(getAmount($deposit->final_amo)); ?> <?php echo e($deposit->method_currency); ?></td>

                                <?php if(request()->routeIs('admin.deposit.approved') || request()->routeIs('admin.deposit.pending')): ?>

                                    <td data-label="<?php echo app('translator')->get('Action'); ?>">
                                        <a href="<?php echo e(route('admin.deposit.details', $deposit->id)); ?>"
                                           class="icon-btn ml-1 " data-toggle="tooltip" title="" data-original-title="Detail">
                                            <i class="la la-eye"></i>
                                        </a>
                                    </td>

                                <?php elseif(request()->routeIs('admin.deposit.list')  || request()->routeIs('admin.deposit.search') || request()->routeIs('admin.users.deposits')): ?>
                                    <td data-label="<?php echo app('translator')->get('Status'); ?>">
                                        <?php if($deposit->status == 2): ?>
                                            <span class="text--small badge font-weight-normal badge--warning"><?php echo app('translator')->get('Pending'); ?></span>
                                        <?php elseif($deposit->status == 1): ?>
                                            <span class="text--small badge font-weight-normal badge--success"><?php echo app('translator')->get('Approved'); ?></span>
                                        <?php elseif($deposit->status == 3): ?>
                                            <span class="text--small badge font-weight-normal badge--danger"><?php echo app('translator')->get('Rejected'); ?></span>
                                        <?php endif; ?>
                                    </td>
                                <?php endif; ?>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td class="text-muted text-center" colspan="100%"><?php echo e($empty_message); ?></td>
                            </tr>
                        <?php endif; ?>

                        </tbody>
                    </table><!-- table end -->
                </div>
            </div>
            <div class="card-footer py-4">
                <?php echo e($deposits->links('admin.partials.paginate')); ?>

            </div>
        </div><!-- card end -->
    </div>
</div>



<?php $__env->stopSection(); ?>


<?php $__env->startPush('breadcrumb-plugins'); ?>
    <?php if(request()->routeIs('admin.users.deposits')): ?>
        <form action="" method="GET" class="form-inline float-sm-right bg--white">
            <div class="input-group has_append">
                <input type="text" name="search" class="form-control" placeholder="Deposit code" value="<?php echo e($search ?? ''); ?>">
                <div class="input-group-append">
                    <button class="btn btn--primary" type="submit"><i class="fa fa-search"></i></button>
                </div>
            </div>
        </form>
    <?php else: ?>

        <form action="<?php echo e(route('admin.deposit.search', $scope ?? str_replace('admin.deposit.', '', request()->route()->getName()))); ?>" method="GET" class="form-inline float-sm-right bg--white">
            <div class="input-group has_append  ">
                <input type="text" name="search" class="form-control" placeholder="Deposit code/Username" value="<?php echo e($search ?? ''); ?>">
                <div class="input-group-append">
                    <button class="btn btn--primary" type="submit"><i class="fa fa-search"></i></button>
                </div>
            </div>
        </form>
    <?php endif; ?>
<?php $__env->stopPush(); ?>



<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/paisakama/dexalsolar.paisakama.com/core/resources/views/admin/deposit/log.blade.php ENDPATH**/ ?>