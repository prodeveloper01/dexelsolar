<?php $__env->startSection('content'); ?>
<?php echo $__env->make($activeTemplate.'breadcrumb', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<style>
  section.cmn-section {
          margin-top:14%!important;
      }    
</style>
<section class="content cmn-section">
			<div class="row">
				<div class="col-xl-3 col-lg-6 col-12">
					<div class="box">
						<div class="box-body">
							<div class="d-flex justify-content-between">
								<h2 class="my-0 fw-600 text-primary"><?php echo e($user->balance + 0); ?> <?php echo e($general->cur_text); ?></h2>
								<div class="w-40 h-40 bg-primary rounded-circle text-center fs-24 l-h-40"><i class="fa fa-inbox"></i></div>
							</div>
							<p class="fs-18 mt-10">Available Funds</p>
						</div>
					</div>
				</div>
				<div class="col-xl-3 col-lg-6 col-12">
					<div class="box">
						<div class="box-body">
							<div class="d-flex justify-content-between">
								<h2 class="my-0 fw-600 text-warning"><?php echo e($user->deposits->sum('amount') + 0); ?> <?php echo e($general->cur_text); ?></h2>
								<div class="w-40 h-40 bg-warning rounded-circle text-center fs-24 l-h-40"><i class="fa fa-shopping-bag"></i></div>
							</div>
							<p class="fs-18 mt-10">Total Deposit</p>
						</div>
					</div>
				</div>
				<div class="col-xl-3 col-lg-6 col-12">
					<div class="box">
						<div class="box-body">
							<div class="d-flex justify-content-between">
								<h2 class="my-0 fw-600 text-info"><?php echo e($user->withdrawals->where('status',1)->sum('amount') + 0); ?> <?php echo e($general->cur_text); ?></h2>
								<div class="w-40 h-40 bg-info rounded-circle text-center fs-24 l-h-40"><i class="fa fa-dollar"></i></div>
							</div>
							<p class="fs-18 mt-10">Total Cashout</p>
						</div>
					</div>
				</div>
				<div class="col-xl-3 col-lg-6 col-12">
					<div class="box">
						<div class="box-body">
							<div class="d-flex justify-content-between">
								<h2 class="my-0 fw-600 text-danger">
                                                                                                                        0
                                                            								</h2>
								<div class="w-40 h-40 bg-danger rounded-circle text-center fs-24 l-h-40"><i class="fa fa-dropbox"></i></div>
							</div>
							<p class="fs-18 mt-10">Active Energy</p>
						</div>
					</div>
				</div>				


			</div>
		</section>






<?php $__env->stopSection(); ?>
<?php $__env->startPush('script'); ?>
<script src="https://cdn.jsdelivr.net/npm/apexcharts"></script>
<script>
(function ($) {
    "use strict";
    // apex-bar-chart js
    var options = {
      series: [{
      name: 'Clicks',
      data: [
        <?php $__currentLoopData = $chart['click']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $click): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php echo e($click); ?>,
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      ]
    }, {
      name: 'Earn Amount',
      data: [
            <?php $__currentLoopData = $chart['amount']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $amount): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php echo e($amount); ?>,
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      ]
    }],
      chart: {
      type: 'bar',
      height: 580,
      toolbar: {
        show: false
      }
    },
    plotOptions: {
      bar: {
        horizontal: false,
        columnWidth: '55%',
        endingShape: 'rounded'
      },
    },
    dataLabels: {
      enabled: false
    },
    stroke: {
      show: true,
      width: 2,
      colors: ['transparent']
    },
    xaxis: {
      categories: [
      <?php $__currentLoopData = $chart['amount']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $amount): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                '<?php echo e($key); ?>',
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    ],
    },
    fill: {
      opacity: 1
    },
    tooltip: {
      y: {
        formatter: function (val) {
          return val
        }
      }
    }
    };
    var chart = new ApexCharts(document.querySelector("#apex-bar-chart"), options);
    chart.render();
        function createCountDown(elementId, sec) {
            var tms = sec;
            var x = setInterval(function() {
                var distance = tms*1000;
                var days = Math.floor(distance / (1000 * 60 * 60 * 24));
                var hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
                var minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
                var seconds = Math.floor((distance % (1000 * 60)) / 1000);
                document.getElementById(elementId).innerHTML =days+"d: "+ hours + "h "+ minutes + "m " + seconds + "s ";
                if (distance < 0) {
                    clearInterval(x);
                    document.getElementById(elementId).innerHTML = "<?php echo e(__('COMPLETE')); ?>";
                }
                tms--;
            }, 1000);
        }
      createCountDown('counter', <?php echo e(\Carbon\Carbon::tomorrow()->diffInSeconds()); ?>);
})(jQuery);
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make($activeTemplate .'layouts.user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/paisakama/dexalsolar.paisakama.com/core/resources/views/templates/basic/user/dashboard.blade.php ENDPATH**/ ?>