<?php $__env->startSection('content'); ?>
<?php echo $__env->make($activeTemplate.'breadcrumb', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<section class="cmn-section">

    <div class="container">
        <div class="row  justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-body">
                        <ul class="list-group text-center">

                            <li class="list-group-item p-prev-list">
                                <img src="<?php echo e($data->gateway_currency()->methodImage()); ?>"/>
                            </li>
                            <p class="list-group-item">
                                <?php echo app('translator')->get('Amount'); ?>:
                                <strong><?php echo e(getAmount($data->amount)); ?> </strong> <?php echo e($general->cur_text); ?>

                            </p>
                            <p class="list-group-item">
                                <?php echo app('translator')->get('Charge'); ?>:
                                <strong><?php echo e(getAmount($data->charge)); ?></strong> <?php echo e($general->cur_text); ?>

                            </p>
                            <p class="list-group-item">
                                <?php echo app('translator')->get('Payable'); ?>: <strong> <?php echo e($data->amount + $data->charge); ?></strong> <?php echo e($general->cur_text); ?>

                            </p>
                            <p class="list-group-item">
                                <?php echo app('translator')->get('Conversion Rate'); ?>: <strong>1 <?php echo e($general->cur_text); ?> = <?php echo e($data->rate +0); ?>  <?php echo e($data->baseCurrency()); ?></strong>
                            </p>
                            <p class="list-group-item">
                                <?php echo app('translator')->get('In'); ?> <?php echo e($data->baseCurrency()); ?>:
                                <strong><?php echo e(getAmount($data->final_amo)); ?></strong>
                            </p>
                            <?php if($data->gateway->crypto==1): ?>
                                <p class="list-group-item">
                                    <?php echo app('translator')->get('Conversion with'); ?>
                                    <b> <?php echo e($data->method_currency); ?></b> <?php echo app('translator')->get('and final value will Show on next step'); ?>
                                </p>
                            <?php endif; ?>
                        </ul>

                        <?php if($data->method_code<1000): ?>
                        <a href="<?php echo e(route('user.deposit.confirm')); ?>" class="btn btn-block py-3 font-weight-bold mt-4 cmn-btn"><?php echo app('translator')->get('Pay Now'); ?></a>
                        <?php else: ?>
                        <a href="<?php echo e(route('user.deposit.manual.confirm')); ?>" class="btn btn-block py-3 font-weight-bold mt-4 cmn-btn"><?php echo app('translator')->get('Pay Now'); ?></a>
                        <?php endif; ?>
                        
                    </div>
                </div>

            </div>
        </div>
    </div>
</section>


<?php $__env->stopSection(); ?>

<?php $__env->startPush('style'); ?>
<style type="text/css">
    .p-prev-list img{
        max-width:100px; 
        max-height:100px; 
        margin:0 auto;
    }
</style>
<?php $__env->stopPush(); ?>
<?php echo $__env->make($activeTemplate .'layouts.user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/paisakama/dexalsolar.paisakama.com/core/resources/views/templates/basic/user/payment/preview.blade.php ENDPATH**/ ?>