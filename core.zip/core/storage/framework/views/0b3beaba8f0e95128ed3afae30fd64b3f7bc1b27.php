<?php $__env->startSection('content'); ?>
<?php echo $__env->make($activeTemplate.'breadcrumb', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<section class="cmn-section">
    <div class="container">
        <div class="row">
            <div class="col-md-12 mb-30">
                <div class="card table-card">
                    <div class="card-body p-0">
                        <div class="table-responsive--sm">
                            <table class="table table-striped">
                                <thead class="thead-dark">
                                <tr>
                                    <th scope="col"><?php echo app('translator')->get('Transaction ID'); ?></th>
                                    <th scope="col"><?php echo app('translator')->get('Gateway'); ?></th>
                                    <th scope="col"><?php echo app('translator')->get('Amount'); ?></th>
                                    <th scope="col"><?php echo app('translator')->get('Status'); ?></th>
                                    <th scope="col"><?php echo app('translator')->get('Time'); ?></th>
                                </tr>
                                </thead>
                                <tbody>
                                <?php if(count($logs) >0): ?>
                                    <?php $__currentLoopData = $logs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k=>$data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td data-label="#<?php echo app('translator')->get('Trx'); ?>"><?php echo e($data->trx); ?></td>
                                            <td data-label="<?php echo app('translator')->get('Gateway'); ?>"><?php echo e($data->gateway->name); ?></td>
                                            <td data-label="<?php echo app('translator')->get('Amount'); ?>">
                                                <strong><?php echo e(getAmount($data->amount)); ?> <?php echo e($general->cur_text); ?></strong>
                                            </td>
                                            <td data-label="status">
                                                <?php if($data->status == 1): ?>
                                                    <span class="badge badge-success"><?php echo app('translator')->get('Complete'); ?></span>
                                                <?php elseif($data->status == 2): ?>
                                                    <span class="badge badge-warning"><?php echo app('translator')->get('Pending'); ?></span>
                                                <?php elseif($data->status == 3): ?>
                                                    <span class="badge badge-danger"><?php echo app('translator')->get('Cancel'); ?></span>

                                                <?php endif; ?>

                                            </td>
                                            <td data-label="<?php echo app('translator')->get('Time'); ?>">
                                                <i class="fa fa-calendar"></i> <?php echo e(date(' d M, Y ', strtotime($data->created_at))); ?>

                                                <i class="fa fa-clock-o pl-1"></i> <?php echo e(date('h:i A', strtotime($data->created_at))); ?>

                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php else: ?>
                                    <tr>
                                        <td colspan="100%" class="text-center"> <?php echo app('translator')->get('No results found'); ?>!</td>
                                    </tr>
                                <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
                <?php echo e($logs->links($activeTemplate.'paginate')); ?>

            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make($activeTemplate .'layouts.user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/paisakama/dexalsolar.paisakama.com/core/resources/views/templates/basic/user/deposit_history.blade.php ENDPATH**/ ?>