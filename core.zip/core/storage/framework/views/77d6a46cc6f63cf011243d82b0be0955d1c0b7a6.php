<?php echo  tawk() ?>
<?php echo  analytics() ?><?php /**PATH /home/paisakama/dexalsolar.paisakama.com/core/resources/views/partials/plugins.blade.php ENDPATH**/ ?>