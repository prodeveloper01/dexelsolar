

<?php $__env->startSection('content'); ?>
    <?php echo $__env->make($activeTemplate.'breadcrumb', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <section class="cmn-section price">
    	<div class="container">
    		<div class="row justify-content-center">
    			<?php $__currentLoopData = $plans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $plan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    			<div class="col-xl-4 col-lg-4 col-md-6 mb-4">
    				<div class="single-price">
    					<div class="part-top">
    						<h3><?php echo e(__($plan->name)); ?></h3>
    						<h4><?php echo e(__($plan->price + 0)); ?> <?php echo e($general->cur_text); ?><br></h4>
    					</div>
    					<div class="part-bottom">
                            <ul>
                                <li><?php echo app('translator')->get('Plan Details'); ?></li>
                                <li><?php echo app('translator')->get('Daily Earning'); ?> : <?php echo e($plan->daily_limit); ?> </li>
                                <li><?php echo app('translator')->get('Referral Bonus'); ?> : <?php echo app('translator')->get('Upto'); ?> <?php echo e($plan->ref_level); ?> <?php echo app('translator')->get('Level'); ?></li>
                                <li><?php echo app('translator')->get('Plan Price'); ?> : <?php echo e(getAmount($plan->price)); ?> <?php echo e(__($general->cur_text)); ?></li>
                                <li><?php echo app('translator')->get('Validity'); ?> : <?php echo app('translator')->get('30 days'); ?></li>
                            </ul>
                            <?php if(auth()->check()): ?>
                            <?php if(auth()->user()->plan_id == $plan->id): ?>
                            <button class="btn btn-success" disabled><?php echo app('translator')->get('Current Plan'); ?></button>
                            <?php else: ?>
                            <button class="btn btn-success" data-id="<?php echo e($plan->id); ?>"><?php echo app('translator')->get('Subscribe Now'); ?></button>
                            <?php endif; ?>
                            <?php else: ?>
                            <button class="btn btn-success" data-id="<?php echo e($plan->id); ?>"><?php echo app('translator')->get('Subscribe Now'); ?></button>
                            <?php endif; ?>
                        </div>
    				</div>
    			</div>
    			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    		</div>
    	</div>
    </section>

    <div id="BuyModal" class="modal fade" role="dialog">
        <div class="modal-dialog">

            <!-- Modal content-->
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title"><?php echo app('translator')->get('Confirmation'); ?></h4>
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                </div>
                <form action="<?php echo e(route('user.buyPlan')); ?>" method="POST">
                    <div class="modal-body text-center">

                        <?php echo e(csrf_field()); ?>

                        <div class="form-group m-0">
                            <input type="hidden" name="id">
                        </div>
                        <strong><?php echo app('translator')->get('Are you sure to subscribe this plan ?'); ?></strong>

                    </div>
                    <div class="modal-footer">
                        <button type="submit" class="btn btn-success"><?php echo app('translator')->get('Confirm'); ?></button>
                        <button type="button" class="btn btn-danger" data-dismiss="modal"><?php echo app('translator')->get('Close'); ?></button>
                    </div>

                </form>
            </div>

        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('script'); ?>
<script type="text/javascript">
    (function ($) {
        "use strict";
    	$('.btn btn-success').click(function(){
    		var modal = $('#BuyModal');
    		modal.find('input[name=id]').val($(this).data('id'));
    		modal.modal('show');
    	});
    })(jQuery);
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make($activeTemplate .'layouts.user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/paisakama/dexalsolar.paisakama.com/core/resources/views/templates/basic/user/plans.blade.php ENDPATH**/ ?>