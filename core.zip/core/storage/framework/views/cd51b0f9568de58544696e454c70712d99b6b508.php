<?php $__env->startSection('content'); ?>
<?php echo $__env->make($activeTemplate.'breadcrumb', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<section class="cmn-section">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-12">
                <?php if($errors->any()): ?>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div><?php echo e($error); ?></div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            </div>


            <?php $__currentLoopData = $gatewayCurrency; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-lg-6 col-md-6 col-sm-12 mb-4">
                    <div class="card">
                        <div class="card-body b-primary">
                            <div class="row">
                                <div class="col-md-5 col-sm-12">
                                    <img src="<?php echo e($data->methodImage()); ?>" class="card-img-top w-100" alt="<?php echo e($data->name); ?>">
                                </div>
                                <div class="col-md-7 col-sm-12">
                                    <ul class="list-group text-center">


                                        <li class="list-group-item">
                                            <?php echo e(__($data->name)); ?></li>

                                        <li class="list-group-item"><?php echo app('translator')->get('Limit'); ?>
                                            : <?php echo e(getAmount($data->min_amount)); ?>

                                            - <?php echo e(getAmount($data->max_amount)); ?> <?php echo e($general->cur_text); ?></li>

                                        <li class="list-group-item"> <?php echo app('translator')->get('Charge'); ?>
                                            - <?php echo e(getAmount($data->fixed_charge)); ?> <?php echo e($general->cur_text); ?>

                                            + <?php echo e(getAmount($data->percent_charge)); ?>%
                                        </li>

                                        <li class="list-group-item">
                                            <button type="button"  data-id="<?php echo e($data->id); ?>" data-resource="<?php echo e($data); ?>"
                                            data-base_symbol="<?php echo e($data->baseSymbol()); ?>"
                                            class=" btn deposit cmn-btn w-100" data-toggle="modal" data-target="#exampleModal">
                                        <?php echo app('translator')->get('Deposit'); ?></button>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


        </div>
    </div>
</section>



    <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <strong class="modal-title method-name" id="exampleModalLabel"></strong>
                    <a href="javascript:void(0)" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </a>
                </div>
                <form action="<?php echo e(route('user.deposit.insert')); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <div class="modal-body">
                        <div class="form-group">
                            <input type="hidden" name="currency" class="edit-currency" value="">
                            <input type="hidden" name="method_code" class="edit-method-code" value="">
                        </div>
                        <div class="form-group">
                            <label><?php echo app('translator')->get('Enter Amount'); ?>:</label>
                            <div class="input-group">
                                <input id="amount" type="text" class="form-control form-control-lg" onkeyup="this.value = this.value.replace (/^\.|[^\d\.]/g, '')" name="amount" placeholder="0.00" required=""  value="<?php echo e(old('amount')); ?>">
                                <div class="input-group-prepend">
                                    <span class="input-group-text currency-addon addon-bg"><?php echo e($general->cur_text); ?></span>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal"><?php echo app('translator')->get('Close'); ?></button>
                        <button type="submit" class="btn btn-primary"><?php echo app('translator')->get('Confirm'); ?></button>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>



<?php $__env->startPush('script'); ?>
    <script>
        (function ($,document) {
            "use strict";
            $(document).ready(function(){

                $('.deposit').on('click', function () {
                    var id = $(this).data('id');
                    var result = $(this).data('resource');
                    var baseSymbol = "<?php echo e($general->cur_text); ?>";
                    // var baseSymbol = $(this).data('base_symbol');

                    $('.method-name').text(`<?php echo app('translator')->get('Payment By '); ?> ${result.name}`);
                    // $('.currency-addon').text(`${result.currency}`);
                    $('.currency-addon').text(baseSymbol);


                    $('.edit-currency').val(result.currency);
                    $('.edit-method-code').val(result.method_code);

                });
            });
        })(jQuery,document);
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make($activeTemplate .'layouts.user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/paisakama/dexalsolar.paisakama.com/core/resources/views/templates/basic/user/payment/deposit.blade.php ENDPATH**/ ?>