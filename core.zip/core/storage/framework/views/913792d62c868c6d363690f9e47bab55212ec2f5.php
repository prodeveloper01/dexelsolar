<section class="py-50">
		<div class="container">
			<div class="row justify-content-center">
				<div class="col-lg-7 col-12 text-center">
					<h1 class="text-uppercase mb-15">WT Power<br> <span class="fw-400 fs-24"> Choose the best</span></h1>
					<p>You can start with minimum 100 every plan is a great plan but bigger plans have bigger earnings. </p>
				</div>
			</div>
			
			<div class="row mt-30">
              <div class="row gap-y text-center">

              <!--- Plans --->
			  <div class="col-md-6 col-lg-3">
				<div class="box shadow-1 hover-shadow-3 transition-5s bg-white b-1 border-success">
				    
				  <center>
				  <br>      
				  <img src="https://wtpower.io/assets/images/spec_1.png" width="74" height="73">
				  </center>    
				  <br>
				  <h2 class="fw-500 fs-60"><span class="price-dollar">
				      Rs</span> 100</h2>
				  <br>

				  <small><b>Rs: 7</b> Daily Earning</small><br>
				  <small><b>Rs: 210</b> Total Profit</small><br>
				  <small><b>Rs: 20</b> Referral Bonus</small><br>
				  <small><b>Rs: 10</b> Minimum Withdraw</small><br>
				  <small><b>30</b> Days Plan</small><br>
				  <br>
				    <div class="d-block">
						<a class="btn btn-success" href="#">Get Started</a>
					</div>
				  <br><br>
				</div>
			  </div>
              <!--- Plans --->
              
              <!--- Plans --->
			  <div class="col-md-6 col-lg-3">
				<div class="box shadow-1 hover-shadow-3 transition-5s bg-white b-1 border-success">
				    
				  <center>
				  <br>      
				  <img src="https://wtpower.io/assets/images/spec_2.png" width="74" height="73">
				  </center>    
				  <br>
				  <h2 class="fw-500 fs-60"><span class="price-dollar">
				      Rs</span> 500</h2>
				  <br>

				  <small><b>Rs: 35</b> Daily Earning</small><br>
				  <small><b>Rs: 1050</b> Total Profit</small><br>
				  <small><b>Rs: 100</b> Referral Bonus</small><br>
				  <small><b>Rs: 70</b> Minimum Withdraw</small><br>
				  <small><b>30</b> Days Plan</small><br>
				  <br>
				    <div class="d-block">
						<a class="btn btn-success" href="#">Get Started</a>
					</div>
				  <br><br>
				</div>
			  </div>
              <!--- Plans --->
              
              <!--- Plans --->
			  <div class="col-md-6 col-lg-3">
				<div class="box shadow-1 hover-shadow-3 transition-5s bg-white b-1 border-success">
				    
				  <center>
				  <br>      
				  <img src="https://wtpower.io/assets/images/spec_3.png" width="74" height="73">
				  </center>    
				  <br>
				  <h2 class="fw-500 fs-60"><span class="price-dollar">
				      Rs</span> 1000</h2>
				  <br>

				  <small><b>Rs: 70</b> Daily Earning</small><br>
				  <small><b>Rs: 2100</b> Total Profit</small><br>
				  <small><b>Rs: 200</b> Referral Bonus</small><br>
				  <small><b>Rs: 140</b> Minimum Withdraw</small><br>
				  <small><b>30</b> Days Plan</small><br>
				  <br>
				    <div class="d-block">
						<a class="btn btn-success" href="#">Get Started</a>
					</div>
				  <br><br>
				</div>
			  </div>
              <!--- Plans --->
              
              <!--- Plans --->
			  <div class="col-md-6 col-lg-3">
				<div class="box shadow-1 hover-shadow-3 transition-5s bg-white b-1 border-success">
				    
				  <center>
				  <br>      
				  <img src="https://wtpower.io/assets/images/spec_4.png" width="74" height="73">
				  </center>    
				  <br>
				  <h2 class="fw-500 fs-60"><span class="price-dollar">
				      Rs</span> 5000</h2>
				  <br>

				  <small><b>Rs: 350</b> Daily Earning</small><br>
				  <small><b>Rs: 10500</b> Total Profit</small><br>
				  <small><b>Rs: 1000</b> Referral Bonus</small><br>
				  <small><b>Rs: 1050</b> Minimum Withdraw</small><br>
				  <small><b>30</b> Days Plan</small><br>
				  <br>
				    <div class="d-block">
						<a class="btn btn-success" href="#">Get Started</a>
					</div>
				  <br><br>
				</div>
			  </div>
              <!--- Plans --->
              
              <!--- Plans --->
			  <div class="col-md-6 col-lg-3">
				<div class="box shadow-1 hover-shadow-3 transition-5s bg-white b-1 border-success">
				    
				  <center>
				  <br>      
				  <img src="https://wtpower.io/assets/images/ser_img_1.png" width="74" height="73">
				  </center>    
				  <br>
				  <h2 class="fw-500 fs-60"><span class="price-dollar">
				      Rs</span> 10000</h2>
				  <br>

				  <small><b>Rs: 700</b> Daily Earning</small><br>
				  <small><b>Rs: 21000</b> Total Profit</small><br>
				  <small><b>Rs: 2000</b> Referral Bonus</small><br>
				  <small><b>Rs: 2100</b> Minimum Withdraw</small><br>
				  <small><b>30</b> Days Plan</small><br>
				  <br>
				    <div class="d-block">
						<a class="btn btn-success" href="#">Get Started</a>
					</div>
				  <br><br>
				</div>
			  </div>
              <!--- Plans --->
              
              <!--- Plans --->
			  <div class="col-md-6 col-lg-3">
				<div class="box shadow-1 hover-shadow-3 transition-5s bg-white b-1 border-success">
				    
				  <center>
				  <br>      
				  <img src="https://wtpower.io/assets/images/ser_img_2.png" width="74" height="73">
				  </center>    
				  <br>
				  <h2 class="fw-500 fs-60"><span class="price-dollar">
				      Rs</span> 25000</h2>
				  <br>

				  <small><b>Rs: 1750</b> Daily Earning</small><br>
				  <small><b>Rs: 52500</b> Total Profit</small><br>
				  <small><b>Rs: 5000</b> Referral Bonus</small><br>
				  <small><b>Rs: 5250</b> Minimum Withdraw</small><br>
				  <small><b>30</b> Days Plan</small><br>
				  <br>
				    <div class="d-block">
						<a class="btn btn-success" href="#">Get Started</a>
					</div>
				  <br><br>
				</div>
			  </div>
              <!--- Plans --->
              
              <!--- Plans --->
			  <div class="col-md-6 col-lg-3">
				<div class="box shadow-1 hover-shadow-3 transition-5s bg-white b-1 border-success">
				    
				  <center>
				  <br>      
				  <img src="https://wtpower.io/assets/images/ser_img_6.png" width="74" height="73">
				  </center>    
				  <br>
				  <h2 class="fw-500 fs-60"><span class="price-dollar">
				      Rs</span> 50000</h2>
				  <br>

				  <small><b>Rs: 3500</b> Daily Earning</small><br>
				  <small><b>Rs: 105000</b> Total Profit</small><br>
				  <small><b>Rs: 10000</b> Referral Bonus</small><br>
				  <small><b>Rs: 14000</b> Minimum Withdraw</small><br>
				  <small><b>30</b> Days Plan</small><br>
				  <br>
				    <div class="d-block">
						<a class="btn btn-success" href="#">Get Started</a>
					</div>
				  <br><br>
				</div>
			  </div>
              <!--- Plans --->
              
              <!--- Plans --->
			  <div class="col-md-6 col-lg-3">
				<div class="box shadow-1 hover-shadow-3 transition-5s bg-white b-1 border-success">
				    
				  <center>
				  <br>      
				  <img src="https://wtpower.io/assets/images/ser_img_3.png" width="74" height="73">
				  </center>    
				  <br>
				  <h2 class="fw-500 fs-60"><span class="price-dollar">
				      Rs</span> 100000</h2>
				  <br>

				  <small><b>Rs: 7000</b> Daily Earning</small><br>
				  <small><b>Rs: 210000</b> Total Profit</small><br>
				  <small><b>Rs: 20000</b> Referral Bonus</small><br>
				  <small><b>Rs: 28000</b> Minimum Withdraw</small><br>
				  <small><b>30</b> Days Plan</small><br>
				  <br>
				    <div class="d-block">
						<a class="btn btn-success" href="#">Get Started</a>
					</div>
				  <br><br>
				</div>
			  </div>
              <!--- Plans --->


			</div>
			</div>
		</div>
	</section><?php /**PATH /home/paisakama/dexalsolar.paisakama.com/core/resources/views/templates/basic/sections/plan.blade.php ENDPATH**/ ?>